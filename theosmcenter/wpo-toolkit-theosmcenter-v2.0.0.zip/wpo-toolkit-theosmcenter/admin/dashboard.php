<?php
/**
 * Admin dashboard: Tools → WPO Toolkit Helper
 * Muestra estado, snapshot velocidad, lista de fixes activos, settings.
 */
defined('ABSPATH') || exit;

add_action('admin_menu', function() {
    add_management_page(
        'WPO Toolkit Helper',
        'WPO Toolkit Helper',
        'manage_options',
        'wpo-toolkit-helper',
        'wpo_toolkit_helper_render_admin'
    );
});

if (!function_exists('wpo_toolkit_helper_get_active_fixes')) {
function wpo_toolkit_helper_get_active_fixes() {
    global $WPO_TOOLKIT_HELPER_CONFIG;
    $list = [];
    if (empty($WPO_TOOLKIT_HELPER_CONFIG['fixes'])) return $list;
    $catalog = wpo_toolkit_helper_fix_catalog();
    foreach ($WPO_TOOLKIT_HELPER_CONFIG['fixes'] as $id => $cfg) {
        if (empty($cfg['enabled'])) continue;
        $meta = $catalog[$id] ?? ['title' => $id, 'category' => '?', 'desc' => ''];
        $list[] = array_merge(['id' => $id], $meta);
    }
    return $list;
}
}

if (!function_exists('wpo_toolkit_helper_fix_catalog')) {
function wpo_toolkit_helper_fix_catalog() {
    return [
        '01-listing-images-priority' => ['title' => 'Imágenes con lazy/eager inteligente', 'category' => 'CLS/LCP', 'desc' => 'Primera imagen del request: eager+fetchpriority=high. Resto lazy.'],
        '02-slider-aspect-ratio' => ['title' => 'Reservar caja del slider hero', 'category' => 'CLS', 'desc' => 'aspect-ratio inline antes de cargar Directorist.'],
        '03-archive-min-height' => ['title' => 'Min-height en archives Directorist', 'category' => 'CLS', 'desc' => 'Reserva 3000-4000px en .article-full para evitar shift cuando llegan las cards.'],
        '04-archive-observer' => ['title' => 'Limpiar inline min-height del archive', 'category' => 'CLS', 'desc' => 'JS+MutationObserver en <head> que anula el style="min-height:0!important" que Directorist inyecta.'],
        '05-block-users-rest' => ['title' => 'Bloquear enumeración de usuarios', 'category' => 'Security', 'desc' => 'Cierra /wp/v2/users y redirige ?author=N a home.'],
        '06-robots-sitemap' => ['title' => 'Sitemap correcto en robots.txt', 'category' => 'SEO', 'desc' => 'Reemplaza /sitemap.xml por /sitemap_index.xml (Yoast/Rank Math).'],
        '07-remove-localbusiness-schema' => ['title' => 'Quitar schema LocalBusiness redundante', 'category' => 'SEO', 'desc' => 'Evita conflicto con apps custom que añaden Physician/FAQPage.'],
        '08-conditional-directorist-assets' => ['title' => 'Solo cargar assets Directorist donde se usan', 'category' => 'Performance', 'desc' => 'Ahorro ~460KB de JS+CSS en home y páginas no Directorist.'],
        '09-ad-slot-reservation' => ['title' => 'Reservar espacio para anuncios (300x250)', 'category' => 'CLS', 'desc' => 'min-height:250px en .ad-wrapper-rentable + ins.adsbygoogle.'],
        '10-preload-lcp-thumbnail' => ['title' => 'Preload del thumbnail principal en single (mobile)', 'category' => 'LCP', 'desc' => '<link rel="preload" as="image"> con la imagen LCP del listing.'],
        '11-block-bot-paths' => ['title' => 'Bloquear paths comunes de bots', 'category' => 'Security', 'desc' => '410 Gone en /wordpress/, /wp/, /old/, etc. 204 en *.js.map / *.css.map.'],
    ];
}
}

if (!function_exists('wpo_toolkit_helper_quick_speed_test')) {
function wpo_toolkit_helper_quick_speed_test() {
    $start = microtime(true);
    $response = wp_remote_get(home_url('/'), [
        'timeout' => 15, 'redirection' => 5, 'sslverify' => false,
        'user-agent' => 'WPO-Toolkit-Helper/' . WPO_TOOLKIT_HELPER_VERSION,
    ]);
    $elapsed = round((microtime(true) - $start) * 1000);
    if (is_wp_error($response)) return ['ok' => false, 'error' => $response->get_error_message(), 'ms' => $elapsed];
    return [
        'ok' => true,
        'status' => wp_remote_retrieve_response_code($response),
        'ms' => $elapsed,
        'bytes' => strlen(wp_remote_retrieve_body($response)),
        'cf' => wp_remote_retrieve_header($response, 'cf-cache-status') ?: '—',
        'rocket' => strpos(wp_remote_retrieve_body($response), 'data-rocket-status') !== false ? 'cached' : '—',
    ];
}
}

if (!function_exists('wpo_toolkit_helper_quick_cron_test')) {
function wpo_toolkit_helper_quick_cron_test() {
    $url = home_url('/wp-cron.php?doing_wp_cron');
    $start = microtime(true);
    $response = wp_remote_get($url, ['timeout' => 30, 'sslverify' => false]);
    $elapsed = round((microtime(true) - $start) * 1000);
    if (is_wp_error($response)) return ['ok' => false, 'error' => $response->get_error_message(), 'ms' => $elapsed];
    $code = wp_remote_retrieve_response_code($response);
    return [
        'ok' => $code >= 200 && $code < 400,
        'status' => $code, 'ms' => $elapsed,
        'verdict' => $code >= 500 ? 'broken' : ($code === 401 || $code === 403 ? 'blocked' : ($elapsed > 5000 ? 'slow' : 'ok')),
    ];
}
}

if (!function_exists('wpo_toolkit_helper_render_admin')) {
function wpo_toolkit_helper_render_admin() {
    if (!current_user_can('manage_options')) return;

    $opt_url = WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'update_url';
    $opt_auto = WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'auto_update';

    $notice = '';
    // Procesar acciones de recommendations primero (tienen su propio nonce)
    $rec_notice = wpo_toolkit_helper_handle_recommendation_actions();
    if ($rec_notice) {
        $notice = $rec_notice['msg'];
    }

    if (isset($_POST['wpo_action']) && check_admin_referer('wpo_toolkit_helper_action')) {
        if ($_POST['wpo_action'] === 'check_update') {
            delete_site_transient('update_plugins');
            wp_update_plugins();
            $notice = '✅ Comprobación lanzada — recarga en 10s.';
        } elseif ($_POST['wpo_action'] === 'save_settings') {
            $url = isset($_POST['update_url']) ? esc_url_raw(wp_unslash($_POST['update_url'])) : '';
            update_option($opt_url, $url);
            update_option($opt_auto, !empty($_POST['auto_update']));
            $notice = '✅ Ajustes guardados.';
        }
    }

    $update_url = get_option($opt_url, WPO_TOOLKIT_HELPER_UPDATE_URL_DEFAULT);
    $auto_update = (bool) get_option($opt_auto, false);
    $fixes = wpo_toolkit_helper_get_active_fixes();
    $speed = wpo_toolkit_helper_quick_speed_test();
    $cron = wpo_toolkit_helper_quick_cron_test();
    $update_check = get_site_transient('update_plugins');
    $has_update = isset($update_check->response[WPO_TOOLKIT_HELPER_BASENAME]);
    $next_cron = wp_next_scheduled('wp_update_plugins');
    ?>
    <div class="wrap wpo-admin">
        <h1 style="display:flex;align-items:center;gap:12px;">
            🛠️ WPO Toolkit Helper
            <span style="font-size:12px;background:#2271b1;color:#fff;padding:2px 8px;border-radius:4px;">v<?php echo esc_html(WPO_TOOLKIT_HELPER_VERSION); ?></span>
            <span style="font-size:12px;color:#646970;"><?php echo esc_html(WPO_TOOLKIT_HELPER_SITE_NAME); ?></span>
        </h1>

        <?php if ($notice): ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html($notice); ?></p></div><?php endif; ?>

        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:16px;margin-top:20px;">

            <div class="card" style="padding:16px;">
                <h2 style="margin-top:0;">Estado</h2>
                <table class="widefat" style="border:none;">
                    <tr><th style="width:140px;">Sitio</th><td><code><?php echo esc_html(WPO_TOOLKIT_HELPER_SITE_KEY); ?></code></td></tr>
                    <tr><th>Versión</th><td><code><?php echo esc_html(WPO_TOOLKIT_HELPER_VERSION); ?></code></td></tr>
                    <tr><th>Fixes activos</th><td><strong><?php echo count($fixes); ?></strong> de <?php echo count(wpo_toolkit_helper_fix_catalog()); ?></td></tr>
                    <tr><th>Update disponible</th><td>
                        <?php if ($has_update): ?>
                            <span style="color:#d63638;">✅ v<?php echo esc_html($update_check->response[WPO_TOOLKIT_HELPER_BASENAME]->new_version); ?></span>
                            <a href="<?php echo esc_url(admin_url('plugins.php')); ?>" class="button button-primary" style="margin-left:8px;">Ir a actualizar</a>
                        <?php else: ?>
                            <span style="color:#00a32a;">✅ Al día</span>
                        <?php endif; ?>
                    </td></tr>
                    <tr><th>Próx. comprobación</th><td><code><?php echo $next_cron ? esc_html(date_i18n('Y-m-d H:i', $next_cron)) : '—'; ?></code></td></tr>
                </table>
                <form method="post" style="margin-top:12px;">
                    <?php wp_nonce_field('wpo_toolkit_helper_action'); ?>
                    <input type="hidden" name="wpo_action" value="check_update">
                    <button type="submit" class="button">🔄 Comprobar updates ahora</button>
                </form>
            </div>

            <div class="card" style="padding:16px;">
                <h2 style="margin-top:0;">⏰ Cron</h2>
                <?php
                $cron_color = $cron['verdict'] === 'ok' ? '#00a32a' : ($cron['verdict'] === 'slow' ? '#dba617' : '#d63638');
                $cron_emoji = ['ok'=>'✅','slow'=>'🐢','blocked'=>'🚫','broken'=>'💥'][$cron['verdict']] ?? '❓';
                ?>
                <p style="font-size:18px;color:<?php echo $cron_color; ?>;"><?php echo $cron_emoji; ?> <strong><?php echo esc_html(strtoupper($cron['verdict'] ?? '?')); ?></strong></p>
                <table class="widefat" style="border:none;">
                    <tr><th style="width:120px;">Status</th><td><code><?php echo esc_html($cron['status'] ?? '—'); ?></code></td></tr>
                    <tr><th>Tiempo</th><td><code><?php echo esc_html($cron['ms']); ?> ms</code></td></tr>
                    <?php if (!empty($cron['error'])): ?>
                    <tr><th>Error</th><td style="color:#d63638;"><?php echo esc_html($cron['error']); ?></td></tr>
                    <?php endif; ?>
                </table>
            </div>

            <div class="card" style="padding:16px;">
                <h2 style="margin-top:0;">⚡ Snapshot velocidad (home)</h2>
                <?php if ($speed['ok']): ?>
                    <table class="widefat" style="border:none;">
                        <tr><th style="width:140px;">TTFB+descarga</th><td><strong><?php echo esc_html($speed['ms']); ?> ms</strong></td></tr>
                        <tr><th>Status</th><td><code><?php echo esc_html($speed['status']); ?></code></td></tr>
                        <tr><th>HTML</th><td><code><?php echo esc_html(round($speed['bytes']/1024, 1)); ?> KB</code></td></tr>
                        <tr><th>Cloudflare</th><td><code><?php echo esc_html($speed['cf']); ?></code></td></tr>
                        <tr><th>WP Rocket</th><td><code><?php echo esc_html($speed['rocket']); ?></code></td></tr>
                    </table>
                <?php else: ?>
                    <p style="color:#d63638;">Error: <?php echo esc_html($speed['error']); ?></p>
                <?php endif; ?>
                <p style="margin-top:12px;">
                    <a href="<?php echo esc_url('https://pagespeed.web.dev/report?url=' . urlencode(home_url('/'))); ?>" target="_blank" class="button">📊 PageSpeed Insights ↗</a>
                </p>
            </div>
        </div>

        <div class="card" style="padding:16px;margin-top:20px;">
            <h2 style="margin-top:0;">¿Qué hace este plugin? <span style="font-weight:normal;font-size:14px;color:#646970;">(<?php echo count($fixes); ?> fixes activos)</span></h2>
            <table class="wp-list-table widefat striped" style="margin-top:8px;">
                <thead><tr><th style="width:30px;">#</th><th style="width:120px;">Categoría</th><th>Fix</th><th>Descripción</th></tr></thead>
                <tbody>
                <?php foreach ($fixes as $i => $f):
                    $cat_color = ['CLS'=>'#dba617','LCP'=>'#dba617','CLS/LCP'=>'#dba617','Security'=>'#d63638','SEO'=>'#2271b1','Performance'=>'#00a32a'][$f['category']] ?? '#646970';
                ?>
                    <tr>
                        <td><?php echo $i + 1; ?></td>
                        <td><span style="background:<?php echo $cat_color; ?>;color:#fff;padding:2px 8px;border-radius:3px;font-size:11px;"><?php echo esc_html($f['category']); ?></span></td>
                        <td><strong><?php echo esc_html($f['title']); ?></strong></td>
                        <td><?php echo esc_html($f['desc']); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php wpo_toolkit_helper_render_recommendations_section(); ?>

        <div class="card" style="padding:16px;margin-top:20px;">
            <h2 style="margin-top:0;">⚙️ Canal de actualizaciones</h2>
            <form method="post">
                <?php wp_nonce_field('wpo_toolkit_helper_action'); ?>
                <input type="hidden" name="wpo_action" value="save_settings">
                <table class="form-table">
                    <tr>
                        <th><label for="update_url">URL del canal</label></th>
                        <td>
                            <input type="url" id="update_url" name="update_url" value="<?php echo esc_attr($update_url); ?>" class="regular-text" style="width:100%;max-width:600px;">
                            <p class="description">JSON con metadatos del plugin específico de este sitio.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="auto_update">Auto-actualizar</label></th>
                        <td>
                            <label><input type="checkbox" id="auto_update" name="auto_update" value="1" <?php checked($auto_update); ?>>
                                Permitir que WP cron auto-actualice este plugin
                            </label>
                        </td>
                    </tr>
                </table>
                <p><button type="submit" class="button button-primary">Guardar</button></p>
            </form>
        </div>

        <div class="card" style="padding:16px;margin-top:20px;">
            <h2 style="margin-top:0;">🔗 Enlaces útiles</h2>
            <p>
                <a href="<?php echo esc_url(admin_url('plugins.php')); ?>" class="button">📦 Plugins</a>
                <a href="<?php echo esc_url(admin_url('site-health.php')); ?>" class="button">🩺 Site Health</a>
                <a href="<?php echo esc_url(admin_url('options-general.php?page=wprocket')); ?>" class="button">🚀 WP Rocket</a>
                <a href="<?php echo esc_url('https://search.google.com/search-console?resource_id=' . urlencode(home_url('/'))); ?>" target="_blank" class="button">📊 Search Console ↗</a>
            </p>
        </div>
    </div>
    <style>
        .wpo-admin .card { background:#fff; border:1px solid #c3c4c7; border-radius:4px; box-shadow:0 1px 1px rgba(0,0,0,.04); }
        .wpo-admin .card h2 { font-size:18px; }
        .wpo-admin .widefat th { font-weight:600; color:#646970; padding:6px 10px; text-align:left; }
        .wpo-admin .widefat td { padding:6px 10px; }
    </style>
    <?php
}
}
