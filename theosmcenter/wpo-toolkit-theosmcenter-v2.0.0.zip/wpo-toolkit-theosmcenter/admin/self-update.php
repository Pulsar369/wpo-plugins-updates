<?php
/**
 * Self-update mechanism — consulta info.json del canal cada 12h.
 * Genérico, parametrizado por las constantes del bootstrap.
 */
defined('ABSPATH') || exit;

add_filter('pre_set_site_transient_update_plugins', function($transient) {
    if (empty($transient->checked)) return $transient;

    $opt_url = WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'update_url';
    $update_url = get_option($opt_url, WPO_TOOLKIT_HELPER_UPDATE_URL_DEFAULT);
    if (empty($update_url)) return $transient;

    $response = wp_remote_get($update_url, ['timeout' => 10, 'sslverify' => true]);
    if (is_wp_error($response)) return $transient;

    $info = json_decode(wp_remote_retrieve_body($response), true);
    if (!is_array($info) || empty($info['version']) || empty($info['package'])) return $transient;

    if (version_compare($info['version'], WPO_TOOLKIT_HELPER_VERSION, '>')) {
        $transient->response[WPO_TOOLKIT_HELPER_BASENAME] = (object) [
            'slug' => WPO_TOOLKIT_HELPER_SLUG,
            'plugin' => WPO_TOOLKIT_HELPER_BASENAME,
            'new_version' => $info['version'],
            'url' => $info['homepage'] ?? home_url('/wp-admin/tools.php?page=wpo-toolkit-helper'),
            'package' => $info['package'],
            'tested' => $info['tested'] ?? get_bloginfo('version'),
            'requires_php' => $info['requires_php'] ?? '7.4',
            'icons' => [], 'banners' => [], 'compatibility' => new stdClass(),
        ];
    }
    return $transient;
});

add_filter('plugins_api', function($result, $action, $args) {
    if ($action !== 'plugin_information') return $result;
    if (empty($args->slug) || $args->slug !== WPO_TOOLKIT_HELPER_SLUG) return $result;

    $opt_url = WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'update_url';
    $update_url = get_option($opt_url, WPO_TOOLKIT_HELPER_UPDATE_URL_DEFAULT);
    if (empty($update_url)) return $result;

    $response = wp_remote_get($update_url, ['timeout' => 10, 'sslverify' => true]);
    if (is_wp_error($response)) return $result;
    $info = json_decode(wp_remote_retrieve_body($response), true);
    if (!is_array($info)) return $result;

    return (object) [
        'name' => $info['name'] ?? 'WPO Toolkit Helper',
        'slug' => WPO_TOOLKIT_HELPER_SLUG,
        'version' => $info['version'] ?? WPO_TOOLKIT_HELPER_VERSION,
        'author' => $info['author'] ?? 'WPO Toolkit',
        'homepage' => $info['homepage'] ?? '',
        'requires' => $info['requires'] ?? '5.0',
        'tested' => $info['tested'] ?? get_bloginfo('version'),
        'requires_php' => $info['requires_php'] ?? '7.4',
        'last_updated' => $info['last_updated'] ?? '',
        'sections' => $info['sections'] ?? ['description' => 'WPO Toolkit Helper'],
        'download_link' => $info['package'] ?? '',
    ];
}, 10, 3);

add_filter('auto_update_plugin', function($update, $item) {
    if (isset($item->plugin) && $item->plugin === WPO_TOOLKIT_HELPER_BASENAME) {
        $opt_auto = WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'auto_update';
        return (bool) get_option($opt_auto, false);
    }
    return $update;
}, 10, 2);

if (!function_exists('wpo_toolkit_helper_uninstall')) {
function wpo_toolkit_helper_uninstall() {
    delete_option(WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'update_url');
    delete_option(WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'auto_update');
}
}
register_uninstall_hook(WPO_TOOLKIT_HELPER_FILE, 'wpo_toolkit_helper_uninstall');
