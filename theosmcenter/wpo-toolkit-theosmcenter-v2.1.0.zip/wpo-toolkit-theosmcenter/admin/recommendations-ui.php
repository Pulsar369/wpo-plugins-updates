<?php
/**
 * UI de recommendations dentro de Tools → WPO Toolkit Helper.
 * Funciones:
 *   wpo_toolkit_helper_render_recommendations_section() — pinta tarjetas
 *   wpo_toolkit_helper_handle_recommendation_actions() — POST handler
 */
defined('ABSPATH') || exit;

if (!function_exists('wpo_toolkit_helper_handle_recommendation_actions')) {
function wpo_toolkit_helper_handle_recommendation_actions() {
    if (!isset($_POST['wpo_rec_action'])) return null;
    if (!check_admin_referer('wpo_toolkit_helper_recommendations')) return null;
    if (!current_user_can('manage_options')) return null;

    $action = sanitize_key($_POST['wpo_rec_action']);
    $issue_id = isset($_POST['issue_id']) ? sanitize_text_field(wp_unslash($_POST['issue_id'])) : '';
    $log_index = isset($_POST['log_index']) ? (int) $_POST['log_index'] : -1;

    if ($action === 'apply' && $issue_id) {
        $r = wpo_toolkit_helper_apply_issue($issue_id);
        return is_wp_error($r) ? ['type'=>'error','msg'=>$r->get_error_message()] : ['type'=>'success','msg'=>'Aplicado: ' . $issue_id];
    }
    if ($action === 'apply_all') {
        $issues = wpo_toolkit_helper_collect_issues();
        $applied = 0; $failed = 0;
        foreach ($issues as $i) {
            if (!empty($i['ignored'])) continue;
            $r = wpo_toolkit_helper_apply_issue($i['id']);
            if (is_wp_error($r)) $failed++; else $applied++;
        }
        return ['type'=>'success','msg'=>"Aplicadas {$applied} recomendaciones (fallaron {$failed})."];
    }
    if ($action === 'ignore' && $issue_id) {
        wpo_toolkit_helper_ignore_issue($issue_id);
        return ['type'=>'info','msg'=>'Ignorado: ' . $issue_id];
    }
    if ($action === 'unignore' && $issue_id) {
        wpo_toolkit_helper_unignore_issue($issue_id);
        return ['type'=>'info','msg'=>'Reactivado: ' . $issue_id];
    }
    if ($action === 'revert' && $log_index >= 0) {
        $r = wpo_toolkit_helper_revert_log_entry($log_index);
        return is_wp_error($r) ? ['type'=>'error','msg'=>$r->get_error_message()] : ['type'=>'success','msg'=>'Revertido.'];
    }
    return null;
}
}

if (!function_exists('wpo_toolkit_helper_severity_color')) {
function wpo_toolkit_helper_severity_color($s) {
    return ['high'=>'#d63638','med'=>'#dba617','low'=>'#646970'][$s] ?? '#646970';
}
}

if (!function_exists('wpo_toolkit_helper_render_recommendations_section')) {
function wpo_toolkit_helper_render_recommendations_section() {
    require_once WPO_TOOLKIT_HELPER_DIR . 'admin/recommendations.php';

    $issues = wpo_toolkit_helper_collect_issues();
    $log = (array) get_option(WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'activity_log', []);
    $by_recommender = [];
    foreach ($issues as $i) {
        $by_recommender[$i['recommender']][] = $i;
    }
    $active_count = 0;
    foreach ($issues as $_i) { if (empty($_i['ignored'])) $active_count++; }
    ?>
    <div class="card" style="padding:16px;margin-top:20px;">
        <h2 style="margin-top:0;display:flex;align-items:center;gap:12px;">
            🎯 Recomendaciones de configuración
            <?php if ($active_count > 0): ?>
                <span style="background:#dba617;color:#fff;padding:2px 10px;border-radius:10px;font-size:12px;"><?php echo $active_count; ?> pendientes</span>
            <?php else: ?>
                <span style="background:#00a32a;color:#fff;padding:2px 10px;border-radius:10px;font-size:12px;">✅ todo OK</span>
            <?php endif; ?>
        </h2>
        <p style="color:#646970;">El plugin escanea las configuraciones de WP, WP Rocket, Perfmatters y Redis. Cada recomendación es opcional — léela, decide y aplica solo lo que tenga sentido para este sitio.</p>

        <?php if (empty($issues)): ?>
            <p style="margin-top:16px;">No hay recomendaciones pendientes. Tu configuración parece correcta.</p>
        <?php else: ?>
            <?php if ($active_count > 1): ?>
                <form method="post" style="margin:12px 0;">
                    <?php wp_nonce_field('wpo_toolkit_helper_recommendations'); ?>
                    <input type="hidden" name="wpo_rec_action" value="apply_all">
                    <button type="submit" class="button button-primary"
                            onclick="return confirm('¿Aplicar todas las recomendaciones no ignoradas? Cada cambio queda registrado en Activity Log y es revertible.')">
                        ✅ Aplicar todas (<?php echo $active_count; ?>)
                    </button>
                </form>
            <?php endif; ?>

            <?php foreach ($by_recommender as $rec => $list): ?>
                <h3 style="margin-top:24px;color:#1d2327;border-bottom:1px solid #c3c4c7;padding-bottom:6px;">
                    <?php echo esc_html(ucwords(str_replace('-', ' ', $rec))); ?>
                </h3>
                <div style="display:grid;grid-template-columns:1fr;gap:8px;">
                    <?php foreach ($list as $i):
                        $sev_color = wpo_toolkit_helper_severity_color($i['severity'] ?? 'low');
                        $is_ignored = !empty($i['ignored']);
                    ?>
                        <div style="border:1px solid #c3c4c7;border-left:4px solid <?php echo $sev_color; ?>;border-radius:4px;padding:12px 16px;background:<?php echo $is_ignored ? '#f6f7f7' : '#fff'; ?>;<?php if ($is_ignored) echo 'opacity:0.6;'; ?>">
                            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:16px;">
                                <div style="flex:1;">
                                    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                                        <span style="background:<?php echo $sev_color; ?>;color:#fff;padding:1px 8px;border-radius:3px;font-size:10px;text-transform:uppercase;letter-spacing:0.5px;">
                                            <?php echo esc_html($i['severity'] ?? 'low'); ?>
                                        </span>
                                        <strong style="font-size:14px;"><?php echo esc_html($i['title']); ?></strong>
                                        <?php if ($is_ignored): ?>
                                            <span style="color:#646970;font-size:11px;">(ignorado)</span>
                                        <?php endif; ?>
                                    </div>
                                    <p style="margin:6px 0 8px;color:#3c434a;"><?php echo esc_html($i['why'] ?? ''); ?></p>
                                    <div style="font-size:12px;color:#646970;font-family:monospace;background:#f6f7f7;padding:6px 10px;border-radius:3px;">
                                        <span style="color:#d63638;"><?php echo esc_html($i['current'] ?? '?'); ?></span>
                                        →
                                        <span style="color:#00a32a;"><?php echo esc_html($i['suggested'] ?? '?'); ?></span>
                                    </div>
                                </div>
                                <div style="display:flex;flex-direction:column;gap:4px;min-width:120px;">
                                    <?php if (!$is_ignored): ?>
                                        <form method="post" style="margin:0;">
                                            <?php wp_nonce_field('wpo_toolkit_helper_recommendations'); ?>
                                            <input type="hidden" name="wpo_rec_action" value="apply">
                                            <input type="hidden" name="issue_id" value="<?php echo esc_attr($i['id']); ?>">
                                            <button type="submit" class="button button-primary" style="width:100%;">Aplicar</button>
                                        </form>
                                        <form method="post" style="margin:0;">
                                            <?php wp_nonce_field('wpo_toolkit_helper_recommendations'); ?>
                                            <input type="hidden" name="wpo_rec_action" value="ignore">
                                            <input type="hidden" name="issue_id" value="<?php echo esc_attr($i['id']); ?>">
                                            <button type="submit" class="button button-link-delete" style="width:100%;">Ignorar</button>
                                        </form>
                                    <?php else: ?>
                                        <form method="post" style="margin:0;">
                                            <?php wp_nonce_field('wpo_toolkit_helper_recommendations'); ?>
                                            <input type="hidden" name="wpo_rec_action" value="unignore">
                                            <input type="hidden" name="issue_id" value="<?php echo esc_attr($i['id']); ?>">
                                            <button type="submit" class="button" style="width:100%;">Reactivar</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Activity log -->
    <?php if (!empty($log)): ?>
    <div class="card" style="padding:16px;margin-top:20px;">
        <h2 style="margin-top:0;">📜 Historial de cambios <span style="font-size:12px;color:#646970;font-weight:normal;">(últimos <?php echo min(count($log), 50); ?>)</span></h2>
        <table class="wp-list-table widefat striped" style="margin-top:8px;">
            <thead><tr><th style="width:140px;">Fecha</th><th style="width:100px;">Acción</th><th>Recomendación</th><th>Cambio</th><th style="width:100px;">Usuario</th><th style="width:100px;"></th></tr></thead>
            <tbody>
                <?php foreach (array_slice($log, 0, 50) as $idx => $entry):
                    $action_color = ['applied'=>'#00a32a','ignored'=>'#646970','reverted'=>'#dba617','apply_failed'=>'#d63638'][$entry['action']] ?? '#646970';
                ?>
                    <tr>
                        <td><?php echo esc_html(date_i18n('Y-m-d H:i', $entry['ts'])); ?></td>
                        <td><span style="background:<?php echo $action_color; ?>;color:#fff;padding:1px 8px;border-radius:3px;font-size:11px;"><?php echo esc_html($entry['action']); ?></span></td>
                        <td>
                            <code><?php echo esc_html($entry['recommender'] ?? '—'); ?></code><br>
                            <strong><?php echo esc_html($entry['title'] ?? $entry['issue_id']); ?></strong>
                        </td>
                        <td>
                            <?php if (!empty($entry['previous'])): ?>
                                <small><?php echo esc_html($entry['previous']); ?> → <?php echo esc_html($entry['new'] ?? '?'); ?></small>
                            <?php elseif (!empty($entry['error'])): ?>
                                <small style="color:#d63638;"><?php echo esc_html($entry['error']); ?></small>
                            <?php else: ?>
                                <small>—</small>
                            <?php endif; ?>
                        </td>
                        <td><code><?php echo esc_html($entry['user'] ?? '—'); ?></code></td>
                        <td>
                            <?php if ($entry['action'] === 'applied'): ?>
                                <form method="post" style="margin:0;">
                                    <?php wp_nonce_field('wpo_toolkit_helper_recommendations'); ?>
                                    <input type="hidden" name="wpo_rec_action" value="revert">
                                    <input type="hidden" name="log_index" value="<?php echo (int) $idx; ?>">
                                    <button type="submit" class="button button-small"
                                            onclick="return confirm('¿Revertir este cambio?')">↩ Revertir</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
    <?php
}
}
