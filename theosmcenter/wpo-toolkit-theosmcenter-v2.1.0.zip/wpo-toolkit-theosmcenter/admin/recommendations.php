<?php
/**
 * Recommendations engine.
 *
 * Cada recommender en /recommenders/*.php debe definir una función
 * wpo_toolkit_recommender_{slug}() que devuelva un array de issues.
 *
 * Forma de un issue:
 *   [
 *     'id'          => 'unique-id',
 *     'recommender' => 'wp-rocket',
 *     'title'       => 'string corto',
 *     'why'         => 'explicación legible',
 *     'severity'    => 'high|med|low',
 *     'current'     => 'valor actual',
 *     'suggested'   => 'valor recomendado',
 *     'apply'       => callable () => bool|WP_Error,
 *     'revert'      => callable () => bool|WP_Error  (opcional),
 *   ]
 *
 * Cuando se aplica un issue, se loggea en la option
 * wpo_toolkit_helper_activity_log para poder revertir.
 */
defined('ABSPATH') || exit;

if (!function_exists('wpo_toolkit_helper_load_recommenders')) {
function wpo_toolkit_helper_load_recommenders() {
    $dir = WPO_TOOLKIT_HELPER_DIR . 'recommenders';
    if (!is_dir($dir)) return [];
    $loaded = [];
    foreach (glob($dir . '/*.php') as $file) {
        require_once $file;
        $slug = basename($file, '.php');
        $fn = 'wpo_toolkit_recommender_' . str_replace('-', '_', $slug);
        if (function_exists($fn)) {
            $loaded[$slug] = $fn;
        }
    }
    return $loaded;
}
}

if (!function_exists('wpo_toolkit_helper_collect_issues')) {
function wpo_toolkit_helper_collect_issues() {
    $issues = [];
    $ignored = (array) get_option(WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'ignored_issues', []);
    foreach (wpo_toolkit_helper_load_recommenders() as $slug => $fn) {
        try {
            $list = call_user_func($fn);
            if (!is_array($list)) continue;
            foreach ($list as $issue) {
                if (empty($issue['id'])) continue;
                $issue['recommender'] = $slug;
                $issue['ignored'] = in_array($issue['id'], $ignored, true);
                $issues[] = $issue;
            }
        } catch (\Throwable $e) {
            // Recommender que falla no debe tumbar el dashboard
            continue;
        }
    }
    return $issues;
}
}

if (!function_exists('wpo_toolkit_helper_log_activity')) {
function wpo_toolkit_helper_log_activity($entry) {
    $log = (array) get_option(WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'activity_log', []);
    $entry['ts'] = time();
    $user = wp_get_current_user();
    $entry['user'] = (!empty($user->user_login)) ? $user->user_login : 'system';
    array_unshift($log, $entry);
    if (count($log) > 200) $log = array_slice($log, 0, 200);
    update_option(WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'activity_log', $log);
}
}

if (!function_exists('wpo_toolkit_helper_apply_issue')) {
function wpo_toolkit_helper_apply_issue($issue_id) {
    $issues = wpo_toolkit_helper_collect_issues();
    $issue = null;
    foreach ($issues as $i) {
        if ($i['id'] === $issue_id) { $issue = $i; break; }
    }
    if (!$issue || empty($issue['apply']) || !is_callable($issue['apply'])) {
        return new WP_Error('not_found', 'Issue not found or no apply callback');
    }

    $result = call_user_func($issue['apply']);
    if (is_wp_error($result) || $result === false) {
        wpo_toolkit_helper_log_activity([
            'action' => 'apply_failed',
            'issue_id' => $issue_id,
            'recommender' => $issue['recommender'],
            'title' => $issue['title'],
            'error' => is_wp_error($result) ? $result->get_error_message() : 'callback returned false',
        ]);
        return $result instanceof WP_Error ? $result : new WP_Error('apply_failed', 'apply() returned false');
    }

    wpo_toolkit_helper_log_activity([
        'action' => 'applied',
        'issue_id' => $issue_id,
        'recommender' => $issue['recommender'],
        'title' => $issue['title'],
        'why' => $issue['why'] ?? '',
        'previous' => $issue['current'] ?? null,
        'new' => $issue['suggested'] ?? null,
    ]);
    return true;
}
}

if (!function_exists('wpo_toolkit_helper_ignore_issue')) {
function wpo_toolkit_helper_ignore_issue($issue_id) {
    $key = WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'ignored_issues';
    $ignored = (array) get_option($key, []);
    if (!in_array($issue_id, $ignored, true)) $ignored[] = $issue_id;
    update_option($key, $ignored);
    wpo_toolkit_helper_log_activity([
        'action' => 'ignored',
        'issue_id' => $issue_id,
    ]);
}
}

if (!function_exists('wpo_toolkit_helper_unignore_issue')) {
function wpo_toolkit_helper_unignore_issue($issue_id) {
    $key = WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'ignored_issues';
    $ignored = array_values(array_diff((array) get_option($key, []), [$issue_id]));
    update_option($key, $ignored);
}
}

if (!function_exists('wpo_toolkit_helper_revert_log_entry')) {
function wpo_toolkit_helper_revert_log_entry($index) {
    $log = (array) get_option(WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'activity_log', []);
    if (!isset($log[$index])) return new WP_Error('not_found', 'Log entry not found');
    $entry = $log[$index];
    if (($entry['action'] ?? '') !== 'applied') return new WP_Error('not_revertible', 'Solo entradas applied son revertibles');

    // Re-buscar el issue por ID y llamar revert si existe
    $issues = wpo_toolkit_helper_collect_issues();
    $issue = null;
    foreach ($issues as $i) {
        if ($i['id'] === $entry['issue_id']) { $issue = $i; break; }
    }
    if (!$issue || empty($issue['revert']) || !is_callable($issue['revert'])) {
        return new WP_Error('not_revertible', 'Este recommender no implementa revert()');
    }
    $result = call_user_func($issue['revert'], $entry);
    if (is_wp_error($result) || $result === false) {
        return $result instanceof WP_Error ? $result : new WP_Error('revert_failed', 'revert() returned false');
    }
    wpo_toolkit_helper_log_activity([
        'action' => 'reverted',
        'issue_id' => $entry['issue_id'],
        'recommender' => $entry['recommender'] ?? '',
        'title' => $entry['title'] ?? '',
        'reverted_index' => $index,
    ]);
    return true;
}
}
