<?php
/**
 * Self-update mechanism — consulta info.json del canal cada 12h.
 * Genérico, parametrizado por las constantes del bootstrap.
 */
defined('ABSPATH') || exit;

add_filter('pre_set_site_transient_update_plugins', function($transient) {
    if (empty($transient->checked)) return $transient;

    $opt_url = WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'update_url';
    $update_url = get_option($opt_url, WPO_TOOLKIT_HELPER_UPDATE_URL_DEFAULT);
    if (empty($update_url)) return $transient;

    $response = wp_remote_get($update_url, ['timeout' => 10, 'sslverify' => true]);
    if (is_wp_error($response)) return $transient;

    $info = json_decode(wp_remote_retrieve_body($response), true);
    if (!is_array($info) || empty($info['version']) || empty($info['package'])) return $transient;

    if (version_compare($info['version'], WPO_TOOLKIT_HELPER_VERSION, '>')) {
        $transient->response[WPO_TOOLKIT_HELPER_BASENAME] = (object) [
            'slug' => WPO_TOOLKIT_HELPER_SLUG,
            'plugin' => WPO_TOOLKIT_HELPER_BASENAME,
            'new_version' => $info['version'],
            'url' => $info['homepage'] ?? home_url('/wp-admin/tools.php?page=wpo-toolkit-helper'),
            'package' => $info['package'],
            'tested' => $info['tested'] ?? get_bloginfo('version'),
            'requires_php' => $info['requires_php'] ?? '7.4',
            'icons' => [], 'banners' => [], 'compatibility' => new stdClass(),
        ];
    }
    return $transient;
});

add_filter('plugins_api', function($result, $action, $args) {
    if ($action !== 'plugin_information') return $result;
    if (empty($args->slug) || $args->slug !== WPO_TOOLKIT_HELPER_SLUG) return $result;

    $opt_url = WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'update_url';
    $update_url = get_option($opt_url, WPO_TOOLKIT_HELPER_UPDATE_URL_DEFAULT);
    if (empty($update_url)) return $result;

    $response = wp_remote_get($update_url, ['timeout' => 10, 'sslverify' => true]);
    if (is_wp_error($response)) return $result;
    $info = json_decode(wp_remote_retrieve_body($response), true);
    if (!is_array($info)) return $result;

    return (object) [
        'name' => $info['name'] ?? 'WPO Toolkit Helper',
        'slug' => WPO_TOOLKIT_HELPER_SLUG,
        'version' => $info['version'] ?? WPO_TOOLKIT_HELPER_VERSION,
        'author' => $info['author'] ?? 'WPO Toolkit',
        'homepage' => $info['homepage'] ?? '',
        'requires' => $info['requires'] ?? '5.0',
        'tested' => $info['tested'] ?? get_bloginfo('version'),
        'requires_php' => $info['requires_php'] ?? '7.4',
        'last_updated' => $info['last_updated'] ?? '',
        'sections' => $info['sections'] ?? ['description' => 'WPO Toolkit Helper'],
        'download_link' => $info['package'] ?? '',
    ];
}, 10, 3);

add_filter('auto_update_plugin', function($update, $item) {
    if (isset($item->plugin) && $item->plugin === WPO_TOOLKIT_HELPER_BASENAME) {
        $opt_auto = WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'auto_update';
        return (bool) get_option($opt_auto, false);
    }
    return $update;
}, 10, 2);

// =============================================================================
//  ROW EN wp-admin/plugins.php — botones rápidos: Dashboard + Auto-update
// =============================================================================

add_filter('plugin_action_links_' . WPO_TOOLKIT_HELPER_BASENAME, function($links) {
    $opt_auto = WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'auto_update';
    $auto_on = (bool) get_option($opt_auto, false);

    // Toggle URL — flip el flag con un nonce
    $toggle_url = wp_nonce_url(
        add_query_arg([
            'action' => 'wpo_toolkit_toggle_autoupdate',
            'value' => $auto_on ? '0' : '1',
        ], admin_url('admin-post.php')),
        'wpo_toolkit_toggle_autoupdate'
    );

    $custom = [
        'dashboard' => '<a href="' . esc_url(admin_url('tools.php?page=wpo-toolkit-helper')) . '" style="font-weight:600;color:#2271b1;">📊 Dashboard</a>',
        'autoupdate' => '<a href="' . esc_url($toggle_url) . '" title="Click para ' . ($auto_on ? 'desactivar' : 'activar') . '">'
            . ($auto_on ? '🔄 Auto-update: ON' : '⏸ Auto-update: OFF')
            . '</a>',
    ];

    return array_merge($custom, $links);
});

// Handler del toggle desde admin-post.php
add_action('admin_post_wpo_toolkit_toggle_autoupdate', function() {
    if (!current_user_can('update_plugins')) wp_die('Sin permisos');
    check_admin_referer('wpo_toolkit_toggle_autoupdate');
    $value = !empty($_GET['value']) && $_GET['value'] === '1';
    update_option(WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'auto_update', $value);
    wp_safe_redirect(wp_get_referer() ?: admin_url('plugins.php'));
    exit;
});

// Meta row debajo de la descripción — info compacta del canal de updates
add_filter('plugin_row_meta', function($meta, $file) {
    if ($file !== WPO_TOOLKIT_HELPER_BASENAME) return $meta;
    $opt_auto = WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'auto_update';
    $auto_on = (bool) get_option($opt_auto, false);
    $next_cron = wp_next_scheduled('wp_update_plugins');
    $next_text = $next_cron ? human_time_diff(time(), $next_cron) : '—';

    $update_url = get_option(WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'update_url', WPO_TOOLKIT_HELPER_UPDATE_URL_DEFAULT);
    $update_short = preg_replace('#^https?://(www\.)?#', '', $update_url);
    $update_short = strlen($update_short) > 60 ? substr($update_short, 0, 57) . '…' : $update_short;

    $meta[] = '<span style="color:' . ($auto_on ? '#00a32a' : '#646970') . ';">' . ($auto_on ? '🟢 Auto-updates ON' : '⚪ Auto-updates OFF') . '</span>';
    $meta[] = '<span style="color:#646970;">Próx. check: <strong>' . esc_html($next_text) . '</strong></span>';
    $meta[] = '<span style="color:#646970;font-family:monospace;font-size:11px;">📡 ' . esc_html($update_short) . '</span>';
    return $meta;
}, 10, 2);

if (!function_exists('wpo_toolkit_helper_uninstall')) {
function wpo_toolkit_helper_uninstall() {
    delete_option(WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'update_url');
    delete_option(WPO_TOOLKIT_HELPER_OPTION_PREFIX . 'auto_update');
}
}
register_uninstall_hook(WPO_TOOLKIT_HELPER_FILE, 'wpo_toolkit_helper_uninstall');
