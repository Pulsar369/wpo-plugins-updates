<?php
// AUTO-GENERATED — no editar a mano.
// Regenerar con: node cli.mjs build-plugin theosmcenter
defined('ABSPATH') || exit;

$WPO_TOOLKIT_HELPER_CONFIG = [
    'site_key' => 'theosmcenter',
    'site_name' => 'The OSM Center',
    'generated_at' => '2026-04-29T11:57:24.034Z',
    'fixes' => [
        '01-listing-images-priority' => [
            'enabled' => true,
            'ratio' => '408/240',
        ],
        '02-slider-aspect-ratio' => [
            'enabled' => true,
        ],
        '03-archive-min-height' => [
            'enabled' => true,
            'archive_min_desktop' => 3000,
            'archive_min_mobile' => 4000,
        ],
        '04-archive-observer' => [
            'enabled' => true,
        ],
        '05-block-users-rest' => [
            'enabled' => true,
        ],
        '06-robots-sitemap' => [
            'enabled' => true,
            'sitemap_path' => '/sitemap_index.xml',
        ],
        '07-remove-localbusiness-schema' => [
            'enabled' => true,
        ],
        '08-conditional-directorist-assets' => [
            'enabled' => true,
        ],
        '09-ad-slot-reservation' => [
            'enabled' => true,
            'min_height' => 250,
        ],
        '10-preload-lcp-thumbnail' => [
            'enabled' => true,
            'cpt' => 'at_biz_dir',
            'meta_keys' => [
                '_listing_prv_img',
                '_listing_thumbnail_id',
            ],
            'fallback_meta' => '_listing_img',
            'size' => 'large',
            'media_query' => '(max-width: 768px)',
        ],
        '11-block-bot-paths' => [
            'enabled' => true,
            'block_maps' => true,
        ],
        '12-adsense-preconnects' => [
            'enabled' => true,
            'only_with_ads' => true,
        ],
    ],
];
