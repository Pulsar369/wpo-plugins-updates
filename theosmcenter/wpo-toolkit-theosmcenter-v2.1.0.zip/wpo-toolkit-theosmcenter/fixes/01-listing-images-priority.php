<?php
/**
 * FIX 01 — Listing images: lazy/eager inteligente
 *
 * Problema: WordPress aplica loading="lazy" a TODAS las imágenes, incluyendo
 * la candidata LCP (primera imagen visible). Eso retrasa el LCP en mobile
 * porque el preload-scanner skipea las imágenes lazy.
 *
 * Fix: Primera imagen del request → eager + fetchpriority=high.
 * Resto → lazy. Aspect-ratio en CSS, no en width/height HTML.
 *
 * Aplica solo si Directorist está activo.
 *
 * Settings ($fix['ratio']): aspect ratio de las cards (default 408/240).
 */
defined('ABSPATH') || exit;

$_fix = isset($WPO_TOOLKIT_HELPER_CURRENT_FIX) ? $WPO_TOOLKIT_HELPER_CURRENT_FIX : [];
$_ratio = isset($_fix['ratio']) ? $_fix['ratio'] : '408/240';

// 1a — Hook propio de Directorist
add_filter('directorist_listing_thumbnail_html', function($html) use ($_ratio) {
    if (strpos($html, '<img') === false) return $html;
    if (strpos($html, ' loading=') !== false) return $html;
    $attrs = wpo_toolkit_helper_img_attrs($_ratio);
    return preg_replace('/<img\s+/', '<img ' . $attrs . ' ', $html, 1);
}, 20);

// 1b — Filter the_content para cards/grid
add_filter('the_content', function($content) use ($_ratio) {
    if (strpos($content, 'directorist-listing-card') === false &&
        strpos($content, 'directorist-listing-single') === false &&
        strpos($content, 'directorist-grid') === false) {
        return $content;
    }
    return preg_replace_callback(
        '/<img\b(?![^>]*\bloading=)[^>]*>/i',
        function($match) use ($_ratio) {
            $tag = $match[0];
            if (strpos($tag, 'directorist') !== false ||
                strpos($tag, 'at-thumb') !== false ||
                strpos($tag, 'card-img') !== false) {
                $attrs = wpo_toolkit_helper_img_attrs($_ratio);
                $tag = str_replace('<img', '<img ' . $attrs, $tag);
            }
            return $tag;
        },
        $content
    );
}, 99);

// 1c — Single listing (CPT at_biz_dir)
add_filter('the_content', function($content) use ($_ratio) {
    if (!is_singular('at_biz_dir')) return $content;
    return preg_replace_callback(
        '/<img\b(?![^>]*\bloading=)[^>]*>/i',
        function($match) use ($_ratio) {
            $attrs = wpo_toolkit_helper_img_attrs($_ratio);
            return str_replace('<img', '<img ' . $attrs, $match[0]);
        },
        $content
    );
}, 98);
