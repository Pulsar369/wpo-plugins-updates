<?php
/**
 * FIX 02 — Reservar caja del slider en single listing
 *
 * Problema: el slider Swiper tarda en cargar y empuja todo hacia abajo
 * cuando llega la primera imagen.
 *
 * Fix: aspect-ratio inline en wp_head ANTES de que llegue el CSS de Directorist.
 * Aplica solo en single listings del CPT at_biz_dir.
 */
defined('ABSPATH') || exit;

add_action('wp_head', function() {
    if (!is_singular('at_biz_dir')) return;
    ?>
    <style id="wpo-toolkit-slider-aspect">
    .directorist-single-listing-slider-wrap,
    .directorist-single-listing-slider,
    .directorist-swiper.directorist-single-listing-slider{aspect-ratio:740/580;min-height:0;contain:layout}
    @media (max-width:768px){
        .directorist-single-listing-slider-wrap,
        .directorist-single-listing-slider{aspect-ratio:740/580;max-height:60vh}
    }
    .directorist-single-listing-slider-thumb{min-height:90px}
    .directorist-thumnail-card-front-img,
    .directorist-thumbnail-card-front-img{aspect-ratio:408/260;object-fit:cover;width:100%;height:auto}
    .directorist-listing-card img.entered,
    .directorist-grid img.entered,
    .directorist-listings-wrapper img.entered{aspect-ratio:408/240;object-fit:cover}
    </style>
    <?php
}, 1);
