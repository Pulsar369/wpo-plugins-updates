<?php
/**
 * FIX 03 — Reservar altura en archives Directorist
 *
 * Problema: páginas tipo /single-category/X/ y /single-location/X/ cargan
 * las cards client-side. Hasta que llegan, el contenedor mide poco y al
 * llenarse empuja anuncios y footer varios miles de px.
 *
 * Fix: min-height en .article-full / .asap-content-box.
 * Aplica solo en URLs single-category/* y single-location/*.
 *
 * Settings ($fix['archive_min_desktop']): default 3000.
 *           ($fix['archive_min_mobile']):  default 4000.
 */
defined('ABSPATH') || exit;

$_fix = isset($WPO_TOOLKIT_HELPER_CURRENT_FIX) ? $WPO_TOOLKIT_HELPER_CURRENT_FIX : [];
$_min_desktop = isset($_fix['archive_min_desktop']) ? (int) $_fix['archive_min_desktop'] : 3000;
$_min_mobile  = isset($_fix['archive_min_mobile'])  ? (int) $_fix['archive_min_mobile']  : 4000;

// Stash en globals porque la closure no captura $_fix correctamente entre includes
$GLOBALS['_wpo_toolkit_archive_min'] = ['desktop' => $_min_desktop, 'mobile' => $_min_mobile];

add_action('wp_head', function() {
    $path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
    if (!preg_match('#^single-(category|location)/#', $path)) return;

    $cfg = isset($GLOBALS['_wpo_toolkit_archive_min']) ? $GLOBALS['_wpo_toolkit_archive_min'] : ['desktop'=>3000,'mobile'=>4000];
    $d = (int) $cfg['desktop'];
    $m = (int) $cfg['mobile'];
    ?>
    <style id="wpo-toolkit-archive-min-height">
    body.directorist-content-active article.article-full,
    body.directorist-preload article.article-full,
    article.article-full,
    body[class*="at_biz_dir"] .article-full {
        min-height: <?php echo $d; ?>px !important;
        contain: layout style;
    }
    body.directorist-content-active div.asap-content-box,
    body.directorist-preload div.asap-content-box,
    div.asap-content-box,
    body[class*="at_biz_dir"] .asap-content-box {
        min-height: <?php echo $d - 200; ?>px !important;
        contain: layout style;
    }
    .directorist-archive-contents,
    .directorist-instant-search,
    .directorist-contents-wrap {
        min-height: <?php echo $d - 800; ?>px !important;
        contain: layout;
    }
    @media (max-width: 768px) {
        body.directorist-content-active article.article-full,
        body.directorist-preload article.article-full,
        article.article-full {
            min-height: <?php echo $m; ?>px !important;
        }
        body.directorist-content-active div.asap-content-box,
        body.directorist-preload div.asap-content-box,
        div.asap-content-box {
            min-height: <?php echo $m - 200; ?>px !important;
        }
        .directorist-archive-contents,
        .directorist-instant-search {
            min-height: <?php echo $m - 1000; ?>px !important;
        }
    }
    [class*="directorist-grid"] article,
    .directorist-listings-wrapper article,
    .directorist-archive-contents article {
        min-height: 320px !important;
        contain: layout;
    }
    </style>
    <?php
}, 1);
