<?php
/**
 * FIX 04 — MutationObserver que limpia inline min-height:0 en archive
 *
 * Problema: Directorist instant-search añade dinámicamente
 * style="min-height:0!important" al article.article-full, anulando el
 * min-height del fix 03. En 3G el JS llega tarde.
 *
 * Fix: JS en wp_head priority 0 (antes que cualquier otro JS) con un
 * MutationObserver global que detecta el article apenas aparece y limpia
 * el inline style.
 *
 * Aplica solo en URLs single-category/* y single-location/*.
 */
defined('ABSPATH') || exit;

add_action('wp_head', function() {
    $path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
    if (!preg_match('#^single-(category|location)/#', $path)) return;
    ?>
    <script id="wpo-toolkit-archive-observer">
    (function(){
        var SELECTORS = ['article.article-full', '.asap-content-box', '.directorist-archive-contents'];
        var observed = new WeakSet();

        function clean(el) {
            if (!el) return;
            var s = el.getAttribute('style') || '';
            if (s.indexOf('min-height') !== -1) {
                el.style.removeProperty('min-height');
            }
        }

        function attachObserver(el) {
            if (!el || observed.has(el)) return;
            observed.add(el);
            clean(el);
            new MutationObserver(function(mutations) {
                for (var i = 0; i < mutations.length; i++) {
                    if (mutations[i].attributeName === 'style') {
                        clean(el);
                        break;
                    }
                }
            }).observe(el, { attributes: true, attributeFilter: ['style'] });
        }

        function attachAll() {
            SELECTORS.forEach(function(sel) {
                document.querySelectorAll(sel).forEach(attachObserver);
            });
        }

        var rootObserver = new MutationObserver(function() { attachAll(); });
        function start() {
            rootObserver.observe(document.documentElement, { childList: true, subtree: true });
            attachAll();
        }
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', start);
            try { rootObserver.observe(document.documentElement, { childList: true, subtree: true }); } catch(e) {}
        } else {
            start();
        }
        [500, 2000, 5000, 10000].forEach(function(ms) { setTimeout(attachAll, ms); });
    })();
    </script>
    <?php
}, 0);
