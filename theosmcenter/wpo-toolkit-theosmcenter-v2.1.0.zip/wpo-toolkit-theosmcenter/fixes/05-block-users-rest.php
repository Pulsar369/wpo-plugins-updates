<?php
/**
 * FIX 05 — Bloquear enumeración de usuarios
 *
 * Problema: por defecto WordPress expone /wp-json/wp/v2/users (lista de admins)
 * y permite enumerar autores via /?author=N. Eso es el primer paso de un ataque.
 *
 * Fix:
 *   - Eliminar endpoints /wp/v2/users y /wp/v2/users/{id} del REST.
 *   - Redirigir 301 a home si alguien usa ?author=N.
 *
 * Universal: aplica a cualquier sitio WordPress.
 */
defined('ABSPATH') || exit;

add_filter('rest_endpoints', function($endpoints) {
    if (isset($endpoints['/wp/v2/users'])) unset($endpoints['/wp/v2/users']);
    if (isset($endpoints['/wp/v2/users/(?P<id>[\d]+)'])) unset($endpoints['/wp/v2/users/(?P<id>[\d]+)']);
    return $endpoints;
});

add_action('template_redirect', function() {
    if (is_admin() || !isset($_GET['author'])) return;
    wp_redirect(home_url(), 301);
    exit;
});
