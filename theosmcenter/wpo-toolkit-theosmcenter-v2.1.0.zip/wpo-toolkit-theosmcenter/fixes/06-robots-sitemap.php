<?php
/**
 * FIX 06 — Sitemap correcto en robots.txt
 *
 * Problema: el robots.txt por defecto apunta a /sitemap.xml. En sitios con
 * Yoast/Rank Math, el sitemap real está en /sitemap_index.xml. Bing y otros
 * buscadores no encontraban el correcto.
 *
 * Fix: en el filter robots_txt, eliminar Sitemap apuntando a /sitemap.xml y
 * añadir Sitemap apuntando a /sitemap_index.xml si no está ya.
 *
 * Settings ($fix['sitemap_path']): default '/sitemap_index.xml'.
 *
 * Universal pero tiene sentido si usas Yoast / Rank Math / All in One SEO.
 */
defined('ABSPATH') || exit;

$_fix = isset($WPO_TOOLKIT_HELPER_CURRENT_FIX) ? $WPO_TOOLKIT_HELPER_CURRENT_FIX : [];
$_sitemap = isset($_fix['sitemap_path']) ? $_fix['sitemap_path'] : '/sitemap_index.xml';
$GLOBALS['_wpo_toolkit_sitemap_path'] = $_sitemap;

add_filter('robots_txt', function($output, $public) {
    if (!$public) return $output;
    $sitemap = isset($GLOBALS['_wpo_toolkit_sitemap_path']) ? $GLOBALS['_wpo_toolkit_sitemap_path'] : '/sitemap_index.xml';
    $output = preg_replace('/Sitemap:\s*https?:\/\/[^\/]+\/sitemap\.xml\s*\n?/i', '', $output);
    if (strpos($output, ltrim($sitemap, '/')) === false) {
        $output .= "\nSitemap: " . home_url($sitemap) . "\n";
    }
    return $output;
}, 10, 2);
