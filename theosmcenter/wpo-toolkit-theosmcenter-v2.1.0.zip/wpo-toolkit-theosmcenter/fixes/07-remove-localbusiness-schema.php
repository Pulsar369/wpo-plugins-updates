<?php
/**
 * FIX 07 — Quitar schema LocalBusiness redundante de Directorist
 *
 * Problema: Directorist añade un schema LocalBusiness en cada single listing.
 * Si el sitio ya tiene una app/plugin custom que añade Physician, FAQPage o
 * similar, los dos schemas confunden a Google y bloquean rich snippets.
 *
 * Fix: eliminar los schema outputs de Directorist via sus propios filters.
 * Aplica solo si Directorist está activo.
 */
defined('ABSPATH') || exit;

add_filter('atbdp_single_listing_schema_output', '__return_empty_string', 99);
add_filter('directorist_single_listing_schema', '__return_empty_array', 99);
add_filter('directorist_business_listing_schema', '__return_empty_array', 99);

add_action('wp_head', function() {
    if (!is_singular('at_biz_dir')) return;
    global $wp_filter;
    if (!isset($wp_filter['wp_head'])) return;
    foreach ($wp_filter['wp_head']->callbacks as $priority => $callbacks) {
        foreach ($callbacks as $key => $cb) {
            $name = '';
            if (is_array($cb['function'])) {
                $obj = $cb['function'][0];
                $method = $cb['function'][1];
                $name = (is_object($obj) ? get_class($obj) : $obj) . '::' . $method;
            } elseif (is_string($cb['function'])) {
                $name = $cb['function'];
            }
            if (stripos($name, 'atbdp') !== false && stripos($name, 'schema') !== false) {
                remove_action('wp_head', $cb['function'], $priority);
            }
        }
    }
}, 1);
