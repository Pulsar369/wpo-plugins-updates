<?php
/**
 * FIX 08 — Solo cargar assets Directorist donde se usan
 *
 * Problema: Directorist enqueue ~460KB de JS+CSS (Swiper, OpenStreetMap,
 * SweetAlert, media uploader) en TODAS las páginas, incluida la home.
 *
 * Fix: condicionar el dequeue según el tipo de página:
 *   - Slider/Map: solo single listing y archives Directorist.
 *   - SweetAlert: single listing + add-listing/dashboard.
 *   - Media uploader: solo submit areas.
 *
 * Aplica solo si Directorist está activo.
 */
defined('ABSPATH') || exit;

add_action('wp_enqueue_scripts', function() {
    $is_single_listing = is_singular('at_biz_dir');
    $path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
    $is_dir_archive = (bool) preg_match('#^single-(category|location)/#', $path);
    $is_submit_area = (bool) preg_match('#^(add-listing|dashboard)(/|$)#', $path);

    $slider = ['directorist-swiper', 'directorist-swiper-style', 'directorist-listing-slider'];
    $map = ['directorist-openstreet-map-leaflet', 'directorist-openstreet-map-openstreet', 'directorist-geolocation', 'directorist-all-location-category'];
    $upload = ['directorist-ez-media-uploader-style'];
    $alert = ['directorist-sweetalert-style'];

    if (!$is_single_listing && !$is_dir_archive) {
        foreach (array_merge($slider, $map) as $h) {
            wp_dequeue_script($h); wp_deregister_script($h);
            wp_dequeue_style($h); wp_deregister_style($h);
        }
    }
    if (!$is_submit_area) {
        foreach ($upload as $h) { wp_dequeue_style($h); wp_deregister_style($h); }
    }
    if (!$is_single_listing && !$is_submit_area) {
        foreach ($alert as $h) { wp_dequeue_style($h); wp_deregister_style($h); }
    }
}, 100);
