<?php
/**
 * FIX 09 — Reservar espacio para slots de anuncios
 *
 * Problema: AdSense / Ad Inserter / GAM cargan los slots asincrónicamente.
 * Mientras llegan, .ad-wrapper-rentable mide 0x0. Cuando se rellena con un
 * 300x250, expande y empuja todo hacia abajo (CLS 0.45 medido en archives).
 *
 * Fix: min-height fijo 250px (mismo formato 300x250 = el más rentable AdSense)
 * en todos los wrappers de anuncios + ins.adsbygoogle. Excepción: anchor ads
 * y overlay ads (no son slots de contenido).
 *
 * Settings ($fix['min_height']): default 250 (formato 300x250 más rentable).
 *
 * Universal — aplica si tienes AdSense, Ad Inserter o GAM.
 */
defined('ABSPATH') || exit;

$_fix = isset($WPO_TOOLKIT_HELPER_CURRENT_FIX) ? $WPO_TOOLKIT_HELPER_CURRENT_FIX : [];
$_min = isset($_fix['min_height']) ? (int) $_fix['min_height'] : 250;
$GLOBALS['_wpo_toolkit_ad_min'] = $_min;

add_action('wp_head', function() {
    $min = isset($GLOBALS['_wpo_toolkit_ad_min']) ? (int) $GLOBALS['_wpo_toolkit_ad_min'] : 250;
    ?>
    <style id="wpo-toolkit-ad-slots">
    .ad-wrapper-rentable,
    [class*="code-block-"] .ad-wrapper-rentable,
    div[id^="div-gpt-ad-"] {
        min-height: <?php echo $min; ?>px !important;
        display: block;
        contain: layout style;
        margin: 0 auto;
        text-align: center;
    }
    ins.adsbygoogle {
        display: block !important;
        min-height: <?php echo $min; ?>px !important;
        contain: layout style;
    }
    ins.adsbygoogle[data-ad-format="auto"][data-anchor-status],
    ins.adsbygoogle[style*="position:fixed"] {
        min-height: 0 !important;
    }
    [id^="ai-block"],
    [class^="ai-block"] {
        contain: layout style;
    }
    </style>
    <?php
}, 1);
