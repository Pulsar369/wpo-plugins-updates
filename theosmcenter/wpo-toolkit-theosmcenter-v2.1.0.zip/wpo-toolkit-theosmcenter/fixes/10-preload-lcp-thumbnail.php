<?php
/**
 * FIX 10 — Preload del thumbnail principal en single listing (mobile)
 *
 * Problema: en /directory/{slug}/, la imagen del slider hero tarda 7+s en
 * aparecer en mobile. WP Rocket le pone loading=lazy y el browser
 * preload-scanner la skipea.
 *
 * Fix: en wp_head, emitir <link rel="preload" as="image" fetchpriority="high">
 * con la URL de la imagen LCP. Solo en mobile (desktop tiene el LCP en otro
 * elemento).
 *
 * Settings ($fix['cpt']): default 'at_biz_dir'.
 *           ($fix['meta_keys']): array de meta keys a probar para encontrar
 *           el thumbnail. Default: _listing_prv_img, _listing_thumbnail_id.
 *           ($fix['fallback_meta']): meta key con array de imágenes (gallery).
 *           ($fix['size']): tamaño WP a usar. Default 'large'.
 *           ($fix['media_query']): default '(max-width: 768px)'.
 */
defined('ABSPATH') || exit;

$_fix = isset($WPO_TOOLKIT_HELPER_CURRENT_FIX) ? $WPO_TOOLKIT_HELPER_CURRENT_FIX : [];
$GLOBALS['_wpo_toolkit_preload_cfg'] = [
    'cpt' => $_fix['cpt'] ?? 'at_biz_dir',
    'meta_keys' => $_fix['meta_keys'] ?? ['_listing_prv_img', '_listing_thumbnail_id'],
    'fallback_meta' => $_fix['fallback_meta'] ?? '_listing_img',
    'size' => $_fix['size'] ?? 'large',
    'media_query' => $_fix['media_query'] ?? '(max-width: 768px)',
];

add_action('wp_head', function() {
    $cfg = $GLOBALS['_wpo_toolkit_preload_cfg'] ?? [];
    if (empty($cfg) || empty($cfg['cpt'])) return;
    if (!is_singular($cfg['cpt'])) return;

    $post_id = get_the_ID();
    if (!$post_id) return;

    $thumbnail_id = null;
    foreach ($cfg['meta_keys'] as $key) {
        $val = get_post_meta($post_id, $key, true);
        if (!empty($val) && is_numeric($val)) { $thumbnail_id = (int) $val; break; }
    }
    if (!$thumbnail_id && !empty($cfg['fallback_meta'])) {
        $images = get_post_meta($post_id, $cfg['fallback_meta'], true);
        if (is_array($images) && !empty($images)) {
            $first = reset($images);
            if (is_numeric($first)) $thumbnail_id = (int) $first;
        }
    }
    if (!$thumbnail_id) {
        $thumbnail_id = get_post_thumbnail_id($post_id);
    }
    if (!$thumbnail_id) return;

    $url = wp_get_attachment_image_url($thumbnail_id, $cfg['size']);
    if (!$url) return;

    // Si el fix 13 está activo y existe versión AVIF/WebP, sustituir.
    // Si no, usar la URL original — el preload-scanner igual descargará
    // la imagen óptima cuando llegue al <img>.
    if (function_exists('wpo_toolkit_modern_url_for')) {
        $url = wpo_toolkit_modern_url_for($url);
    }

    // type hint si el URL acaba en avif/webp — ayuda al preload-scanner
    // a saber si su browser soporta el formato sin parsear el binario.
    $type = '';
    if (preg_match('/\.avif(\?|$)/i', $url)) $type = ' type="image/avif"';
    elseif (preg_match('/\.webp(\?|$)/i', $url)) $type = ' type="image/webp"';

    echo '<link rel="preload" as="image" href="' . esc_url($url) . '" fetchpriority="high"' . $type;
    if (!empty($cfg['media_query'])) {
        echo ' media="' . esc_attr($cfg['media_query']) . '"';
    }
    echo ">\n";
}, 1);
