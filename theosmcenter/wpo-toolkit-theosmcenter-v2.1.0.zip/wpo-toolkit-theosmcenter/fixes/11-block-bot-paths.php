<?php
/**
 * FIX 11 — Bloquear paths comunes de bots fingerprinting
 *
 * Problema: bots escanean paths típicos para detectar WordPress y plugins
 * (/wordpress/, /wp/, /old/, /test/, /backup/, etc) o piden source maps
 * que no existen (.js.map, .css.map). Eso ensucia los logs del Redirection
 * plugin con cientos de 404s.
 *
 * Fix: interceptar template_redirect en paths sospechosos y devolver 410 Gone
 * sin renderizar nada (más rápido que 404 + el bot lo registra como "ya no
 * existe", reduciendo retries).
 *
 * Settings ($fix['paths']): array de paths/regex a bloquear.
 *           ($fix['block_maps']): si true, devuelve 204 a *.map (default true).
 *
 * Universal opcional.
 */
defined('ABSPATH') || exit;

$_fix = isset($WPO_TOOLKIT_HELPER_CURRENT_FIX) ? $WPO_TOOLKIT_HELPER_CURRENT_FIX : [];
$GLOBALS['_wpo_toolkit_blocked_paths'] = [
    'paths' => $_fix['paths'] ?? [
        '#^wordpress/?$#',
        '#^wp/?$#',
        '#^old/?$#',
        '#^test/?$#',
        '#^backup/?$#',
        '#^xmlrpc\.php$#',
        '#^wp-config\.php\.bak$#',
    ],
    'block_maps' => $_fix['block_maps'] ?? true,
];

add_action('init', function() {
    $cfg = $GLOBALS['_wpo_toolkit_blocked_paths'] ?? null;
    if (!$cfg) return;

    $path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
    if (empty($path)) return;

    if ($cfg['block_maps'] && preg_match('/\.(js|css)\.map$/', $path)) {
        status_header(204);
        nocache_headers();
        exit;
    }

    foreach ($cfg['paths'] as $pattern) {
        if (preg_match($pattern, $path)) {
            status_header(410);
            nocache_headers();
            exit;
        }
    }
}, 1);
