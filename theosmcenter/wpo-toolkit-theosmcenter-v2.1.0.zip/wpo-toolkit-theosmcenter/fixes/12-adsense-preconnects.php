<?php
/**
 * FIX 12 — Preconnects para AdSense / Google Ads
 *
 * Problema: cuando hay un anuncio AdSense above-the-fold, el navegador hace
 * el handshake TLS con varios hosts de Google en serie. Cada handshake son
 * 100-300ms en mobile/3G. Con 4 hosts → 400-1200ms añadidos al LCP.
 *
 * Fix: <link rel="preconnect"> en wp_head para los 4 hosts críticos.
 *
 * IMPORTANTE: el script moderno de AdSense usa crossorigin="anonymous", así
 * que cada preconnect se duplica (sin crossorigin + con crossorigin) para
 * que el browser reutilice la conexión en ambos casos. Sin esa duplicación
 * el preconnect NO se reutiliza para el fetch real.
 *
 * Solo activar si detectamos AdSense en el sitio (slot above-the-fold) —
 * preconnectar a hosts que solo entran en juego tras 2-3s ralentiza el LCP
 * en lugar de mejorarlo.
 *
 * Settings ($fix['hosts']): array de hosts a preconnectar.
 *           ($fix['only_with_ads']): si true, sólo en URLs con anuncios above-the-fold (default true).
 *           ($fix['include_pagead2']): preconnect adicional a pagead2 (default true).
 */
defined('ABSPATH') || exit;

$_fix = isset($WPO_TOOLKIT_HELPER_CURRENT_FIX) ? $WPO_TOOLKIT_HELPER_CURRENT_FIX : [];
$GLOBALS['_wpo_toolkit_adsense_cfg'] = [
    'hosts' => $_fix['hosts'] ?? [
        'https://adservice.google.com',
        'https://googleads.g.doubleclick.net',
        'https://www.googletagservices.com',
        'https://tpc.googlesyndication.com',
    ],
    'only_with_ads' => $_fix['only_with_ads'] ?? true,
    'include_pagead2' => $_fix['include_pagead2'] ?? true,
];

add_action('wp_head', function() {
    $cfg = $GLOBALS['_wpo_toolkit_adsense_cfg'] ?? null;
    if (!$cfg) return;

    // Si only_with_ads, no preconectar en páginas obvias sin ads (admin, login)
    if (!empty($cfg['only_with_ads']) && (is_admin() || is_login())) return;

    $hosts = $cfg['hosts'];
    if (!empty($cfg['include_pagead2'])) {
        $hosts[] = 'https://pagead2.googlesyndication.com';
    }

    foreach ($hosts as $h) {
        $h = esc_url($h);
        // Cada preconnect duplicado: el script de AdSense usa crossorigin="anonymous"
        // pero también hace fetches sin él. Sin la duplicación, el browser abre
        // una segunda conexión TCP/TLS y el preconnect no aprovecha.
        echo '<link rel="preconnect" href="' . $h . '">' . "\n";
        echo '<link rel="preconnect" href="' . $h . '" crossorigin="anonymous">' . "\n";
    }
}, 2);
