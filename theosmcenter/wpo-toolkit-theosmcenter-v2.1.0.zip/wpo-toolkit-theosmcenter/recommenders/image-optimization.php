<?php
/**
 * Recommender: Image optimization
 *
 * Detecta:
 *   1. Si hay un plugin de optimización de imágenes ya instalado/activo.
 *   2. Capacidades del servidor (GD/Imagick, soporte AVIF/WebP).
 *   3. Si Cloudflare Polish está disponible (a través del audit, no aquí).
 *
 * Recomendaciones:
 *   - Si NO hay plugin Y server soporta AVIF → "Instala Converter for Media (free)"
 *   - Si NO hay plugin Y server NO soporta AVIF → "Instala Imagify (cloud)"
 *   - Si hay plugin pero no genera AVIF → "Activa AVIF en el plugin X"
 *   - Si hay AVIF/WebP files pero no se sirven → "Activa fix #13 serve-modern-formats"
 *
 * El recommender NO instala nada — solo informa y enlaza.
 */
defined('ABSPATH') || exit;

if (!function_exists('wpo_toolkit_recommender_image_optimization')) {
function wpo_toolkit_recommender_image_optimization() {
    $issues = [];

    // 1. ¿Hay un plugin de optimización activo?
    $known_plugins = [
        'imagify/imagify.php' => 'Imagify',
        'shortpixel-image-optimiser/wp-shortpixel.php' => 'ShortPixel',
        'wp-smushit/wp-smush.php' => 'Smush',
        'ewww-image-optimizer/ewww-image-optimizer.php' => 'EWWW',
        'webp-converter-for-media/webp-converter-for-media.php' => 'Converter for Media',
        'avif-local-support/avif-local-support.php' => 'AVIF Local Support',
        'image-optimization/image-optimization.php' => 'Image Optimizer (Elementor)',
        'optimole-wp/optimole-wp.php' => 'Optimole',
        'compressx/compressx.php' => 'CompressX',
    ];
    $detected_plugin = null;
    foreach ($known_plugins as $path => $name) {
        if (is_plugin_active($path)) { $detected_plugin = $name; break; }
    }

    // 2. Capacidades del servidor
    $caps = wpo_toolkit_image_caps();

    // 3. Detectar si HAY archivos .webp/.avif en el upload pero el server
    //    no los está sirviendo (sin Vary: Accept o sin rewrite)
    $upload_dir = wp_upload_dir();
    $has_webp_files = false; $has_avif_files = false;
    if (!empty($upload_dir['basedir']) && is_dir($upload_dir['basedir'])) {
        // Sample superficial: solo carpetas YYYY/MM más recientes
        $year_dir = $upload_dir['basedir'] . '/' . date('Y');
        if (is_dir($year_dir)) {
            $month_dir = $year_dir . '/' . date('m');
            if (is_dir($month_dir)) {
                $files = @scandir($month_dir) ?: [];
                foreach ($files as $f) {
                    if (preg_match('/\.webp$/i', $f)) { $has_webp_files = true; }
                    if (preg_match('/\.avif$/i', $f)) { $has_avif_files = true; }
                    if ($has_webp_files && $has_avif_files) break;
                }
            }
        }
    }

    // ─── ISSUES ─────────────────────────────────────────────────────────

    if (!$detected_plugin) {
        if ($caps['avif_gd'] || $caps['avif_imagick']) {
            $issues[] = [
                'id' => 'img-no-plugin-server-avif',
                'title' => 'No hay plugin de optimización de imágenes',
                'why' => 'Tu servidor SOPORTA AVIF (' . ($caps['avif_imagick'] ? 'Imagick' : 'GD') . '). Recomendado: Converter for Media (gratis, encode en background, sin coste por imagen).',
                'severity' => 'med',
                'current' => 'sin plugin',
                'suggested' => 'Converter for Media',
                // No aplicamos automáticamente — instalar plugins requiere FTP/curl
                // y es decisión del usuario.
            ];
        } else {
            $issues[] = [
                'id' => 'img-no-plugin-server-no-avif',
                'title' => 'No hay plugin de optimización de imágenes',
                'why' => 'Tu servidor NO soporta AVIF nativo. Recomendado: Imagify (free 25MB/mes, integración nativa con WP Rocket que ya tienes), o Cloudflare Polish si tienes plan Pro.',
                'severity' => 'med',
                'current' => 'sin plugin · server sin AVIF',
                'suggested' => 'Imagify o Cloudflare Polish',
            ];
        }
    }

    if ($detected_plugin && !$has_webp_files && !$has_avif_files) {
        $issues[] = [
            'id' => 'img-plugin-no-conversion',
            'title' => $detected_plugin . ' no está convirtiendo a WebP/AVIF',
            'why' => 'Detecto el plugin instalado, pero la carpeta uploads/' . date('Y/m') . '/ no tiene ningún .webp ni .avif. Verifica en su panel que la conversión esté activa.',
            'severity' => 'med',
            'current' => $detected_plugin . ' instalado · 0 modern files',
            'suggested' => 'Activa conversión + bulk optimize',
        ];
    }

    if (($has_webp_files || $has_avif_files)) {
        global $WPO_TOOLKIT_HELPER_CONFIG;
        $serve_fix_active = !empty($WPO_TOOLKIT_HELPER_CONFIG['fixes']['13-serve-modern-formats']['enabled']);
        if (!$serve_fix_active) {
            $issues[] = [
                'id' => 'img-modern-files-not-served',
                'title' => 'Tienes WebP/AVIF generados pero quizá no se sirven',
                'why' => 'La carpeta uploads/' . date('Y/m') . '/ contiene archivos .webp/.avif. Si el plugin que los genera no los sirve, el browser sigue descargando el JPG. Activa el fix #13 (serve-modern-formats) en este plugin para asegurar que se sirvan vía Accept header.',
                'severity' => 'med',
                'current' => 'modern files presentes · fix 13 OFF',
                'suggested' => 'fix 13 ON',
            ];
        }
    }

    // Server caps info — no es un issue, solo info útil para debug
    if (!$caps['avif_gd'] && !$caps['avif_imagick'] && !$caps['webp_gd'] && !$caps['webp_imagick']) {
        $issues[] = [
            'id' => 'img-server-no-modern-support',
            'title' => 'Servidor sin soporte WebP/AVIF nativo',
            'why' => 'Ni GD ni Imagick tienen soporte para formatos modernos. Solo podrás usar plugins cloud (Imagify, Cloudflare, ShortPixel). Si pides al hosting compilar GD con libwebp/libavif, podrías usar plugins locales.',
            'severity' => 'low',
            'current' => 'GD/Imagick sin WebP/AVIF',
            'suggested' => 'pide al hosting libwebp + libavif, o usa plugin cloud',
        ];
    }

    return $issues;
}
}

if (!function_exists('wpo_toolkit_image_caps')) {
function wpo_toolkit_image_caps() {
    $caps = ['gd' => false, 'imagick' => false, 'webp_gd' => false, 'avif_gd' => false, 'webp_imagick' => false, 'avif_imagick' => false];

    if (extension_loaded('gd')) {
        $caps['gd'] = true;
        $info = function_exists('gd_info') ? gd_info() : [];
        $caps['webp_gd'] = !empty($info['WebP Support']);
        $caps['avif_gd'] = !empty($info['AVIF Support']);
    }
    if (extension_loaded('imagick') && class_exists('Imagick')) {
        $caps['imagick'] = true;
        try {
            $formats = Imagick::queryFormats();
            $caps['webp_imagick'] = in_array('WEBP', $formats, true);
            $caps['avif_imagick'] = in_array('AVIF', $formats, true) || in_array('HEIC', $formats, true);
        } catch (\Throwable $e) {
            // queryFormats puede fallar en setups raros — ignorar
        }
    }
    return $caps;
}
}
