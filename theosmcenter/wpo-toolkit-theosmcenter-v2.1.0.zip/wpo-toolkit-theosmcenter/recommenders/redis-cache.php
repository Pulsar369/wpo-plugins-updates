<?php
/**
 * Recommender: Redis Object Cache
 *
 * Verifica que Redis está activo y conectado. Si lo detectamos pero no se
 * está usando como object cache, reportamos.
 */
defined('ABSPATH') || exit;

if (!function_exists('wpo_toolkit_recommender_redis_cache')) {
function wpo_toolkit_recommender_redis_cache() {
    if (!is_plugin_active('redis-cache/redis-cache.php')) return [];

    $issues = [];

    // Detectar si el drop-in object-cache.php está activo
    $dropin_present = file_exists(WP_CONTENT_DIR . '/object-cache.php');
    if (!$dropin_present) {
        $issues[] = [
            'id' => 'redis-no-dropin',
            'title' => 'Redis Cache instalado pero no activado',
            'why' => 'Sin el drop-in /wp-content/object-cache.php, Redis no está cacheando nada. Vete a Settings → Redis y haz click en "Enable Object Cache".',
            'severity' => 'high',
            'current' => 'object-cache.php: missing',
            'suggested' => 'click Enable Object Cache',
            // No lo aplicamos automáticamente porque requiere copiar un drop-in
            // (mejor que el usuario lo haga desde el panel de Redis Cache).
        ];
    }

    // Si está, comprobar config recomendada
    $cfg = (array) get_option('redis-cache', []);
    $maxttl = (int) ($cfg['cache_ttl'] ?? 0);
    if ($dropin_present && $maxttl === 0) {
        $issues[] = [
            'id' => 'redis-no-ttl',
            'title' => 'Redis sin TTL global',
            'why' => 'Sin TTL, las entradas viven hasta que Redis hace eviction por memoria. Recomendable 1 día (86400) o 1 semana.',
            'severity' => 'low',
            'current' => 'cache_ttl: 0',
            'suggested' => 'cache_ttl: 86400 (1 día)',
            'apply' => function () {
                $c = (array) get_option('redis-cache', []);
                $c['cache_ttl'] = 86400;
                update_option('redis-cache', $c);
                return true;
            },
            'revert' => function () {
                $c = (array) get_option('redis-cache', []);
                $c['cache_ttl'] = 0;
                update_option('redis-cache', $c);
                return true;
            },
        ];
    }

    return $issues;
}
}
