<?php
/**
 * Recommender: WordPress core
 *
 * Settings nativos de WP que casi siempre conviene ajustar:
 *   - Auto-update minor releases
 *   - Permalinks no-default (mejor SEO + cache)
 *   - Eliminar emojis y embeds (vía wp_head action)
 *   - Limitar revisiones (define WP_POST_REVISIONS) — solo recomendable, no aplicable
 *   - Comments cerrados en posts antiguos si no se usan
 */
defined('ABSPATH') || exit;

if (!function_exists('wpo_toolkit_recommender_wp_core')) {
function wpo_toolkit_recommender_wp_core() {
    $issues = [];

    // 1. Auto-update minor releases
    $auto_minor = get_site_option('auto_update_core_minor', 'enabled');
    if ($auto_minor !== 'enabled') {
        $issues[] = [
            'id' => 'core-auto-minor',
            'title' => 'Auto-update de minor releases desactivado',
            'why' => 'Los minor releases (5.x.Y) son parches de seguridad — siempre conviene aplicarlos automáticamente.',
            'severity' => 'med',
            'current' => 'auto_update_core_minor: ' . $auto_minor,
            'suggested' => 'enabled',
            'apply' => function () {
                update_site_option('auto_update_core_minor', 'enabled');
                return true;
            },
        ];
    }

    // 2. Permalinks
    $permalink = get_option('permalink_structure', '');
    if (empty($permalink) || $permalink === '/?p=%post_id%') {
        $issues[] = [
            'id' => 'core-permalinks',
            'title' => 'Permalinks por defecto (?p=ID)',
            'why' => 'URLs amigables (/post-name/) son mejor para SEO y se cachean mejor que querystrings.',
            'severity' => 'high',
            'current' => 'permalink_structure: ' . ($permalink ?: 'default'),
            'suggested' => '/%postname%/',
            'apply' => function () {
                global $wp_rewrite;
                update_option('permalink_structure', '/%postname%/');
                if ($wp_rewrite) $wp_rewrite->flush_rules();
                return true;
            },
        ];
    }

    // 3. Indexing — alguien marcó "discourage search engines" sin querer
    if (get_option('blog_public') === '0' || get_option('blog_public') === 0) {
        $issues[] = [
            'id' => 'core-blog-public',
            'title' => 'Indexación de buscadores DESACTIVADA',
            'why' => 'Settings → Reading → "Discourage search engines" está marcado. Si esto es producción, NO te indexa Google.',
            'severity' => 'high',
            'current' => 'blog_public: 0',
            'suggested' => '1',
            'apply' => function () {
                update_option('blog_public', '1');
                return true;
            },
        ];
    }

    // 4. Default ping_sites
    $ping = trim((string) get_option('ping_sites', ''));
    if ($ping === 'http://rpc.pingomatic.com/') {
        $issues[] = [
            'id' => 'core-ping-sites',
            'title' => 'Ping a rpc.pingomatic.com (legado)',
            'why' => 'Servicio prácticamente muerto. Cada publish hace una request HTTP innecesaria que ralentiza el guardado.',
            'severity' => 'low',
            'current' => $ping,
            'suggested' => '(vacío)',
            'apply' => function () {
                update_option('ping_sites', '');
                return true;
            },
            'revert' => function () {
                update_option('ping_sites', 'http://rpc.pingomatic.com/');
                return true;
            },
        ];
    }

    return $issues;
}
}
