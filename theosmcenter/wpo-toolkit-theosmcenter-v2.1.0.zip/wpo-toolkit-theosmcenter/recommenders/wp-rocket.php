<?php
/**
 * Recommender: WP Rocket
 *
 * Lee la opción 'wp_rocket_settings' y propone cambios para mejorar
 * performance sin riesgo. Cada issue tiene un apply() y un revert() que
 * usan el snapshot de valores previos almacenados en la option de log.
 *
 * Las claves del array de WP Rocket que tocamos:
 *   - lazyload, lazyload_iframes, lazyload_youtube
 *   - minify_css, minify_js
 *   - defer_all_js, async_css
 *   - emoji, embeds (limpieza WP)
 *   - control_heartbeat, heartbeat_admin_behavior, heartbeat_site_behavior
 *   - manual_preload (smart preload)
 *   - dns_prefetch (con CDN)
 *   - schedule_automatic_cleanup, automatic_cleanup_frequency
 */
defined('ABSPATH') || exit;

if (!function_exists('wpo_toolkit_recommender_wp_rocket')) {
function wpo_toolkit_recommender_wp_rocket() {
    if (!is_plugin_active('wp-rocket/wp-rocket.php')
        && !function_exists('rocket_clean_domain')) {
        return [];
    }
    $settings = (array) get_option('wp_rocket_settings', []);
    if (empty($settings)) return [];

    $issues = [];

    $bool_recommendations = [
        // [option_key, recommended_value, severity, title, why]
        ['lazyload', 1, 'high',
            'Lazy load de imágenes desactivado',
            'Cargar todas las imágenes a la vez retrasa el LCP en mobile 2-3s. Activar lazy load mantiene la imagen "above the fold" y posterga el resto.'],
        ['lazyload_iframes', 1, 'med',
            'Lazy load de iframes desactivado',
            'Embeds de YouTube/Vimeo cargan ~500KB cada uno antes de tiempo.'],
        ['lazyload_youtube', 1, 'med',
            'Reemplazar iframes YouTube por preview',
            'Reemplaza el iframe pesado por una imagen estática hasta que se hace click.'],
        ['minify_css', 1, 'med',
            'Minificación CSS desactivada',
            'Reduce 10-20% el peso del CSS. Si rompe estilos, hay un campo "exclude CSS files".'],
        ['minify_js', 1, 'med',
            'Minificación JS desactivada',
            'Reduce 10-20% el peso del JS. Excluir manualmente JS problemático si rompe.'],
        ['defer_all_js', 1, 'med',
            'Defer JS desactivado',
            'Defer permite que el HTML se renderice sin esperar a JS. Mejor TBT y FCP.'],
        ['emoji', 1, 'low',
            'Emojis WP no deshabilitados',
            'WP carga wp-emoji-release.min.js (~10KB) para emojis nativos. Casi nadie los usa.'],
        ['embeds', 1, 'low',
            'Embeds WP no deshabilitados',
            'Reduce JS innecesario relacionado con oEmbed.'],
        ['control_heartbeat', 1, 'med',
            'Heartbeat sin control',
            'WP envía AJAX cada 15s desde el admin → stress al servidor. Throttle a 60s reduce CPU.'],
    ];

    foreach ($bool_recommendations as [$key, $rec, $sev, $title, $why]) {
        $current = (int) ($settings[$key] ?? 0);
        if ($current === (int) $rec) continue;
        $issues[] = [
            'id' => 'wpr-' . $key,
            'title' => $title,
            'why' => $why,
            'severity' => $sev,
            'current' => $key . ': ' . $current,
            'suggested' => $key . ': ' . $rec,
            'apply' => function () use ($key, $rec) {
                $s = (array) get_option('wp_rocket_settings', []);
                $s[$key] = $rec;
                update_option('wp_rocket_settings', $s);
                if (function_exists('rocket_clean_domain')) rocket_clean_domain();
                return true;
            },
            'revert' => function ($entry) use ($key) {
                $prev = $entry['previous'] ?? '';
                $val = is_string($prev) && strpos($prev, ':') !== false
                    ? (int) trim(substr($prev, strpos($prev, ':') + 1))
                    : 0;
                $s = (array) get_option('wp_rocket_settings', []);
                $s[$key] = $val;
                update_option('wp_rocket_settings', $s);
                if (function_exists('rocket_clean_domain')) rocket_clean_domain();
                return true;
            },
        ];
    }

    // Heartbeat throttle: si está desactivado, el valor por defecto es 60s
    if (!empty($settings['control_heartbeat'])) {
        $admin = $settings['heartbeat_admin_behavior'] ?? 'reduce_periodicity';
        if ($admin === 'disable') {
            $issues[] = [
                'id' => 'wpr-heartbeat-disabled-admin',
                'title' => 'Heartbeat completamente desactivado en admin',
                'why' => 'Mejor "reduce" (60s) que "disable" — algunos plugins lo necesitan (ej: edits autosave).',
                'severity' => 'low',
                'current' => 'admin: disable',
                'suggested' => 'admin: reduce',
                'apply' => function () {
                    $s = (array) get_option('wp_rocket_settings', []);
                    $s['heartbeat_admin_behavior'] = 'reduce_periodicity';
                    update_option('wp_rocket_settings', $s);
                    return true;
                },
            ];
        }
    }

    // Database cleanup automático
    if (empty($settings['schedule_automatic_cleanup'])) {
        $issues[] = [
            'id' => 'wpr-db-cleanup',
            'title' => 'Limpieza automática de base de datos desactivada',
            'why' => 'Acumula revisiones, transients expirados, comentarios spam. Limpieza semanal mantiene la DB rápida.',
            'severity' => 'low',
            'current' => 'schedule_automatic_cleanup: 0',
            'suggested' => 'schedule_automatic_cleanup: 1, frequency: weekly',
            'apply' => function () {
                $s = (array) get_option('wp_rocket_settings', []);
                $s['schedule_automatic_cleanup'] = 1;
                $s['automatic_cleanup_frequency'] = 'weekly';
                update_option('wp_rocket_settings', $s);
                return true;
            },
            'revert' => function () {
                $s = (array) get_option('wp_rocket_settings', []);
                $s['schedule_automatic_cleanup'] = 0;
                update_option('wp_rocket_settings', $s);
                return true;
            },
        ];
    }

    return $issues;
}
}
