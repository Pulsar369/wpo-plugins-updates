<?php
/**
 * Plugin Name:       WPO Toolkit Helper — The OSM Center
 * Plugin URI:        https://theosmcenter.com
 * Description:       WPO Toolkit Helper para The OSM Center. 12 fixes activos según último wp-audit (2026-04-28T11-52-21-wp-audit).
 * Version:           2.1.0
 * Author:            WPO Toolkit
 * License:           GPL v2 or later
 * Requires at least: 5.0
 * Requires PHP:      7.4
 * Update URI:        https://raw.githubusercontent.com/Pulsar369/wpo-plugins-updates/main/theosmcenter/info.json
 */

defined('ABSPATH') || exit;

// =============================================================================
//  GUARD MAESTRO — si ya hay otra instancia activa, salir limpiamente
// =============================================================================
if (defined('WPO_TOOLKIT_HELPER_VERSION')) {
    return;
}

// =============================================================================
//  CONSTANTES — parametrizadas por el builder
// =============================================================================
define('WPO_TOOLKIT_HELPER_VERSION', '2.1.0');
define('WPO_TOOLKIT_HELPER_FILE', __FILE__);
define('WPO_TOOLKIT_HELPER_BASENAME', plugin_basename(__FILE__));
define('WPO_TOOLKIT_HELPER_SLUG', dirname(plugin_basename(__FILE__)));
define('WPO_TOOLKIT_HELPER_DIR', plugin_dir_path(__FILE__));
define('WPO_TOOLKIT_HELPER_SITE_KEY', 'theosmcenter');
define('WPO_TOOLKIT_HELPER_SITE_NAME', 'The OSM Center');
define('WPO_TOOLKIT_HELPER_UPDATE_URL_DEFAULT', 'https://raw.githubusercontent.com/Pulsar369/wpo-plugins-updates/main/theosmcenter/info.json');
define('WPO_TOOLKIT_HELPER_OPTION_PREFIX', 'wpo_toolkit_helper_');

// =============================================================================
//  CONFIGURACIÓN — qué fixes están activos en este build
//  El builder genera config.php con un array $WPO_TOOLKIT_HELPER_CONFIG.
// =============================================================================
$config_file = __DIR__ . '/config.php';
if (!file_exists($config_file)) {
    add_action('admin_notices', function() {
        echo '<div class="notice notice-error"><p><strong>WPO Toolkit Helper:</strong> falta <code>config.php</code>. Reinstala el plugin desde el toolkit.</p></div>';
    });
    return;
}
require_once $config_file;
if (!isset($WPO_TOOLKIT_HELPER_CONFIG) || !is_array($WPO_TOOLKIT_HELPER_CONFIG)) {
    return;
}

// =============================================================================
//  RESET CONTADOR DE PRIMERA IMAGEN POR REQUEST (para LCP)
//  Compartido entre fixes; declarado en bootstrap antes de cargar fixes.
// =============================================================================
add_action('wp', function() {
    $GLOBALS['_wpo_toolkit_first_img_used'] = false;
});

if (!function_exists('wpo_toolkit_helper_img_attrs')) {
function wpo_toolkit_helper_img_attrs($aspect_ratio = '408/240') {
    $is_first = empty($GLOBALS['_wpo_toolkit_first_img_used']);
    $GLOBALS['_wpo_toolkit_first_img_used'] = true;
    $loading = $is_first ? 'eager' : 'lazy';
    $priority = $is_first ? ' fetchpriority="high"' : '';
    $style = 'aspect-ratio:' . esc_attr($aspect_ratio) . ';width:100%;height:auto;object-fit:cover;';
    return 'loading="' . $loading . '" decoding="async"' . $priority . ' style="' . $style . '"';
}
}

// =============================================================================
//  CARGAR FIXES HABILITADOS
// =============================================================================
$enabled_fixes = isset($WPO_TOOLKIT_HELPER_CONFIG['fixes']) ? $WPO_TOOLKIT_HELPER_CONFIG['fixes'] : [];
foreach ($enabled_fixes as $fix_id => $fix_settings) {
    if (empty($fix_settings['enabled'])) continue;
    $fix_file = WPO_TOOLKIT_HELPER_DIR . 'fixes/' . $fix_id . '.php';
    if (file_exists($fix_file)) {
        $WPO_TOOLKIT_HELPER_CURRENT_FIX = $fix_settings;
        require_once $fix_file;
    }
}

// =============================================================================
//  ADMIN DASHBOARD + SELF-UPDATE + RECOMMENDATIONS — solo en admin
//  (en frontend solo se cargan los fixes + self-update; el resto es admin-only)
// =============================================================================
if (is_admin()) {
    if (!function_exists('is_plugin_active')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    require_once WPO_TOOLKIT_HELPER_DIR . 'admin/recommendations.php';
    require_once WPO_TOOLKIT_HELPER_DIR . 'admin/recommendations-ui.php';
    require_once WPO_TOOLKIT_HELPER_DIR . 'admin/dashboard.php';
}
// Self-update se carga en cualquier contexto porque usa cron
require_once WPO_TOOLKIT_HELPER_DIR . 'admin/self-update.php';
