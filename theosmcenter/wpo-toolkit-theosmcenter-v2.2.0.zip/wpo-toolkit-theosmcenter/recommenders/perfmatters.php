<?php
/**
 * Recommender: Perfmatters
 *
 * Toggles típicos que casi siempre conviene activar:
 *   - Disable Embeds, Emojis, Dashicons (frontend), jQuery Migrate
 *   - Disable WLW Manifest, RSD link, Shortlinks, Self pingbacks, Pingbacks REST
 *   - Heartbeat: disable backend (mejor reduce 60s pero perfmatters solo permite disable)
 *   - Disable Block CSS si no se usa Gutenberg
 */
defined('ABSPATH') || exit;

if (!function_exists('wpo_toolkit_recommender_perfmatters')) {
function wpo_toolkit_recommender_perfmatters() {
    if (!is_plugin_active('perfmatters/perfmatters.php')) return [];
    $opts = (array) get_option('perfmatters_options', []);
    if (empty($opts)) return [];

    $issues = [];

    $bool_recommendations = [
        ['disable_emojis', 1, 'low', 'Emojis WP no deshabilitados',
            'wp-emoji-release.min.js (~10KB) cargado en cada página sin uso real.',
            'Ahorro 10KB JS + 2 requests por página',
            ['Perfmatters → Options → Disable Emojis → ON', 'Verificar Network: ya no aparece wp-emoji-release.min.js']],
        ['disable_embeds', 1, 'low', 'Embeds WP no deshabilitados',
            'oEmbed añade ~5KB JS sin uso si no incrustas tweets / vídeos.',
            'Ahorro 5-10KB JS',
            ['Perfmatters → Options → Disable Embeds → ON', 'Solo activar si no usas embeds nativos de WP']],
        ['disable_dashicons', 1, 'low', 'Dashicons cargados en frontend',
            'Iconos del admin que no aplican en frontend público.',
            'Ahorro 50KB CSS frontend',
            ['Perfmatters → Options → Disable Dashicons → ON', 'Si tu tema/plugin usa Dashicons en frontend, podría romper']],
        ['disable_jquery_migrate', 1, 'low', 'jQuery Migrate cargando',
            'Compatibilidad con jQuery 1.x — ya no necesario en temas/plugins modernos.',
            'Ahorro 10KB JS + parsing',
            ['Perfmatters → Options → Disable jQuery Migrate → ON', 'Verificar funcionalidad: sliders, formularios, lightbox', 'Si rompe algo, revertir desde Activity log']],
        ['disable_self_pingbacks', 1, 'low', 'Self-pingbacks no deshabilitados',
            'Cada vez que linkeas a otro post tuyo, WP hace ping HTTP a sí mismo.',
            'Reduce server load al publicar posts con enlaces internos',
            ['Perfmatters → Options → Disable Self Pingbacks → ON', 'Sin efecto visible para el visitante']],
        ['remove_query_strings', 1, 'low', 'Query strings en assets',
            'Algunos CDNs no cachean URLs con ?ver=X. Quitar mejora cache hit.',
            'Mejor cache hit en CDNs antiguos. Cloudflare ya las cachea bien con ignore querystring',
            ['Perfmatters → Options → Remove Query Strings → ON', 'Verificar que CSS/JS siguen cargando con DevTools Network']],
    ];

    foreach ($bool_recommendations as [$key, $rec, $sev, $title, $why, $impact, $details]) {
        $current = (int) ($opts[$key] ?? 0);
        if ($current === (int) $rec) continue;
        $issues[] = [
            'id' => 'pm-' . str_replace('_', '-', $key),
            'title' => $title,
            'why' => $why,
            'severity' => $sev,
            'current' => $key . ': ' . $current,
            'suggested' => $key . ': ' . $rec,
            'estimated_impact' => $impact,
            'details' => $details,
            'apply' => function () use ($key, $rec) {
                $o = (array) get_option('perfmatters_options', []);
                $o[$key] = $rec;
                update_option('perfmatters_options', $o);
                return true;
            },
            'verify' => function () use ($key, $rec) {
                $o = (array) get_option('perfmatters_options', []);
                return (int) ($o[$key] ?? 0) === (int) $rec;
            },
            'revert' => function () use ($key) {
                $o = (array) get_option('perfmatters_options', []);
                $o[$key] = 0;
                update_option('perfmatters_options', $o);
                return true;
            },
        ];
    }

    return $issues;
}
}
