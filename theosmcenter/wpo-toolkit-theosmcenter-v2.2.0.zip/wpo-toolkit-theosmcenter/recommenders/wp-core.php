<?php
/**
 * Recommender: WordPress core
 *
 * Settings nativos de WP que casi siempre conviene ajustar:
 *   - Auto-update minor releases
 *   - Permalinks no-default (mejor SEO + cache)
 *   - Eliminar emojis y embeds (vía wp_head action)
 *   - Limitar revisiones (define WP_POST_REVISIONS) — solo recomendable, no aplicable
 *   - Comments cerrados en posts antiguos si no se usan
 */
defined('ABSPATH') || exit;

if (!function_exists('wpo_toolkit_recommender_wp_core')) {
function wpo_toolkit_recommender_wp_core() {
    $issues = [];

    // 1. Auto-update minor releases
    $auto_minor = get_site_option('auto_update_core_minor', 'enabled');
    if ($auto_minor !== 'enabled') {
        $issues[] = [
            'id' => 'core-auto-minor',
            'title' => 'Auto-update de minor releases desactivado',
            'why' => 'Los minor releases (5.x.Y) son parches de seguridad — siempre conviene aplicarlos automáticamente.',
            'severity' => 'med',
            'current' => 'auto_update_core_minor: ' . $auto_minor,
            'suggested' => 'enabled',
            'estimated_impact' => 'Seguridad — parches CVE aplicados automáticamente sin intervención',
            'details' => [
                'Setting: site option auto_update_core_minor = "enabled"',
                'WP comprobará nuevos minor releases (5.4.x, 5.5.x...) cada 12h',
                'Si hay update, se aplica solo en background sin que el sitio caiga',
                'Esto NO afecta a updates major (6.0 → 7.0) — esos siguen requiriendo click manual',
                'Equivalente al toggle Settings → Updates → "Automatically update minor and security releases"'
            ],
            'apply' => function () {
                update_site_option('auto_update_core_minor', 'enabled');
                return true;
            },
            'verify' => function () {
                return get_site_option('auto_update_core_minor') === 'enabled';
            },
        ];
    }

    // 2. Permalinks
    $permalink = get_option('permalink_structure', '');
    if (empty($permalink) || $permalink === '/?p=%post_id%') {
        $issues[] = [
            'id' => 'core-permalinks',
            'title' => 'Permalinks por defecto (?p=ID)',
            'why' => 'URLs amigables (/post-name/) son mejor para SEO y se cachean mejor que querystrings.',
            'severity' => 'high',
            'current' => 'permalink_structure: ' . ($permalink ?: 'default'),
            'suggested' => '/%postname%/',
            'estimated_impact' => 'SEO mejor + URLs cacheables. Cambia formato de TODAS las URLs',
            'details' => [
                '⚠️ ESTO CAMBIA TODAS LAS URLs DE TU SITIO — los enlaces antiguos (?p=123) seguirán funcionando vía redirect, pero verifica los enlaces externos importantes',
                'Setting equivalente: Settings → Permalinks → "Post name" → Save',
                'Setting cambiado: permalink_structure → "/%postname%/"',
                'Tras aplicar: WP regenera .htaccess automáticamente con las rewrite rules',
                'Verificar inmediatamente que un post abre correctamente (/sample-post/)',
                'Si hosting Nginx (no Apache), pedir al hosting actualizar configuración de URLs'
            ],
            'apply' => function () {
                global $wp_rewrite;
                update_option('permalink_structure', '/%postname%/');
                if ($wp_rewrite) $wp_rewrite->flush_rules();
                return true;
            },
            'verify' => function () {
                return get_option('permalink_structure') === '/%postname%/';
            },
        ];
    }

    // 3. Indexing — alguien marcó "discourage search engines" sin querer
    if (get_option('blog_public') === '0' || get_option('blog_public') === 0) {
        $issues[] = [
            'id' => 'core-blog-public',
            'title' => 'Indexación de buscadores DESACTIVADA',
            'why' => 'Settings → Reading → "Discourage search engines" está marcado. Si esto es producción, NO te indexa Google.',
            'severity' => 'high',
            'current' => 'blog_public: 0',
            'suggested' => '1',
            'estimated_impact' => 'CRÍTICO: si esto está mal, Google NO indexa el sitio. Tráfico orgánico = 0',
            'details' => [
                '⚠️ Esto es probablemente la causa #1 si no rankeas en Google',
                'Setting equivalente: Settings → Reading → "Search engine visibility" → DESMARCAR "Discourage search engines from indexing this site"',
                'Tras aplicar, robots.txt cambia: las directivas Disallow desaparecen',
                'Tras 1-7 días Google empezará a indexar las nuevas URLs',
                'Forzar reindexación inmediata: Search Console → URL Inspection → Request indexing'
            ],
            'apply' => function () {
                update_option('blog_public', '1');
                return true;
            },
            'verify' => function () {
                return (string) get_option('blog_public') === '1';
            },
        ];
    }

    // 4. Default ping_sites
    $ping = trim((string) get_option('ping_sites', ''));
    if ($ping === 'http://rpc.pingomatic.com/') {
        $issues[] = [
            'id' => 'core-ping-sites',
            'title' => 'Ping a rpc.pingomatic.com (legado)',
            'why' => 'Servicio prácticamente muerto. Cada publish hace una request HTTP innecesaria que ralentiza el guardado.',
            'severity' => 'low',
            'current' => $ping,
            'suggested' => '(vacío)',
            'estimated_impact' => 'Reducción ~500ms en el tiempo de "Publish" de cada post. Sin impacto en frontend',
            'details' => [
                'Setting equivalente: Settings → Writing → "Update Services" → vaciar el textarea',
                'Pingomatic estaba diseñado para avisar a buscadores cuando publicabas — Google lo ignora hace años',
                'Cada publish hace una request POST a rpc.pingomatic.com que tarda y a veces falla',
                'Quitarlo no afecta a SEO ni indexación moderna (Google usa sitemaps + Search Console)'
            ],
            'apply' => function () {
                update_option('ping_sites', '');
                return true;
            },
            'verify' => function () {
                return trim((string) get_option('ping_sites', '')) === '';
            },
            'revert' => function () {
                update_option('ping_sites', 'http://rpc.pingomatic.com/');
                return true;
            },
        ];
    }

    return $issues;
}
}
