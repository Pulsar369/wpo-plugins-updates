<?php
/**
 * Recommender: WP Rocket
 *
 * Lee la opción 'wp_rocket_settings' y propone cambios para mejorar
 * performance sin riesgo. Cada issue tiene un apply() y un revert() que
 * usan el snapshot de valores previos almacenados en la option de log.
 *
 * Las claves del array de WP Rocket que tocamos:
 *   - lazyload, lazyload_iframes, lazyload_youtube
 *   - minify_css, minify_js
 *   - defer_all_js, async_css
 *   - emoji, embeds (limpieza WP)
 *   - control_heartbeat, heartbeat_admin_behavior, heartbeat_site_behavior
 *   - manual_preload (smart preload)
 *   - dns_prefetch (con CDN)
 *   - schedule_automatic_cleanup, automatic_cleanup_frequency
 */
defined('ABSPATH') || exit;

if (!function_exists('wpo_toolkit_recommender_wp_rocket')) {
function wpo_toolkit_recommender_wp_rocket() {
    if (!is_plugin_active('wp-rocket/wp-rocket.php')
        && !function_exists('rocket_clean_domain')) {
        return [];
    }
    $settings = (array) get_option('wp_rocket_settings', []);
    if (empty($settings)) return [];

    $issues = [];

    $bool_recommendations = [
        // [option_key, value, severity, title, why, estimated_impact, details[]]
        ['lazyload', 1, 'high',
            'Lazy load de imágenes desactivado',
            'Cargar todas las imágenes a la vez retrasa el LCP en mobile 2-3s. Activar lazy load mantiene la imagen "above the fold" y posterga el resto.',
            'LCP -1.5 a -3s en mobile, ahorro 200-800KB de transferencia inicial',
            [
                'WP Rocket → Settings → Media → "LazyLoad" → marcar "Enable for images"',
                'Verifica que las imágenes en WP Admin > Media tengan loading="lazy" tras un purge cache',
                'La primera imagen above-the-fold se queda eager (compatible con fix #01 del plugin)',
                'Si rompe algún slider, añadir clase a "Excluded images" en WP Rocket'
            ]],
        ['lazyload_iframes', 1, 'med',
            'Lazy load de iframes desactivado',
            'Embeds de YouTube/Vimeo cargan ~500KB cada uno antes de tiempo.',
            'Ahorro 500KB-2MB por iframe en TBT y data transfer',
            [
                'WP Rocket → Settings → Media → "LazyLoad" → marcar "Enable for iframes and videos"',
                'Verifica con DevTools Network: los iframes solo deben cargar cuando entren en viewport'
            ]],
        ['lazyload_youtube', 1, 'med',
            'Reemplazar iframes YouTube por preview',
            'Reemplaza el iframe pesado por una imagen estática hasta que se hace click.',
            'Ahorro ~500KB de JS por video YouTube',
            [
                'WP Rocket → Settings → Media → "LazyLoad" → marcar "Replace YouTube iframe with preview image"',
                'Verifica abriendo un post con video: debe verse thumbnail con botón Play'
            ]],
        ['minify_css', 1, 'med',
            'Minificación CSS desactivada',
            'Reduce 10-20% el peso del CSS. Si rompe estilos, hay un campo "exclude CSS files".',
            'Ahorro 10-20% del peso de CSS (~30-100KB en sites medios)',
            [
                'WP Rocket → Settings → File Optimization → CSS Files → marcar "Minify CSS files"',
                'Hacer hard refresh (Ctrl+F5) y verificar que la web se ve igual',
                'Si algún estilo rompe, identifica el archivo en DevTools y añádelo a "Excluded CSS files"',
                'WP Rocket purga cache automáticamente al guardar'
            ]],
        ['minify_js', 1, 'med',
            'Minificación JS desactivada',
            'Reduce 10-20% el peso del JS. Excluir manualmente JS problemático si rompe.',
            'Ahorro 10-20% del peso de JS (~50-150KB en sites medios)',
            [
                'WP Rocket → Settings → File Optimization → JavaScript Files → marcar "Minify JavaScript files"',
                'NO marcar "Combine JavaScript" — peligroso, suele romper sites con muchos plugins',
                'Verificar funcionalidad: formularios, sliders, lightbox, navegación móvil',
                'Si rompe, añadir el JS culpable a "Excluded JavaScript Files"'
            ]],
        ['defer_all_js', 1, 'med',
            'Defer JS desactivado',
            'Defer permite que el HTML se renderice sin esperar a JS. Mejor TBT y FCP.',
            'TBT -100 a -300ms, FCP -0.5 a -1s',
            [
                'WP Rocket → Settings → File Optimization → JavaScript Files → marcar "Load JavaScript deferred"',
                'Recomendado marcar "Use Safe Mode for jQuery" si tu tema/plugins dependen de jQuery',
                'Tras activar, verifica que NO hay errores JS en DevTools Console',
                'Si hay scripts inline que dependen de jQuery cargado, añadirlos a "Excluded JavaScript Files"'
            ]],
        ['emoji', 1, 'low',
            'Emojis WP no deshabilitados',
            'WP carga wp-emoji-release.min.js (~10KB) para emojis nativos. Casi nadie los usa.',
            'Ahorro 10KB JS + 2 requests por página',
            [
                'WP Rocket → Settings → File Optimization → Disable Emoji',
                'Verificar que los emojis nativos del navegador siguen funcionando (suelen sí)'
            ]],
        ['embeds', 1, 'low',
            'Embeds WP no deshabilitados',
            'Reduce JS innecesario relacionado con oEmbed.',
            'Ahorro 5-10KB JS',
            [
                'WP Rocket → Settings → File Optimization → Disable WordPress Embeds',
                'Solo activa esto si NO usas embeds nativos de WP (raro)'
            ]],
        ['control_heartbeat', 1, 'med',
            'Heartbeat sin control',
            'WP envía AJAX cada 15s desde el admin → stress al servidor. Throttle a 60s reduce CPU.',
            'Reducción 75% de requests heartbeat → menor uso CPU en hosting compartido',
            [
                'WP Rocket → Settings → Heartbeat → marcar "Control Heartbeat"',
                'Recomendado: Backend = "Reduce activity", Frontend = "Disable", Editor = "Reduce"',
                'NO ponerlo en "Disable" en backend si usas autosave de Gutenberg'
            ]],
    ];

    foreach ($bool_recommendations as [$key, $rec, $sev, $title, $why, $impact, $details]) {
        $current = (int) ($settings[$key] ?? 0);
        if ($current === (int) $rec) continue;
        $issues[] = [
            'id' => 'wpr-' . $key,
            'title' => $title,
            'why' => $why,
            'severity' => $sev,
            'current' => $key . ': ' . $current,
            'suggested' => $key . ': ' . $rec,
            'estimated_impact' => $impact,
            'details' => $details,
            'apply' => function () use ($key, $rec) {
                $s = (array) get_option('wp_rocket_settings', []);
                $s[$key] = $rec;
                update_option('wp_rocket_settings', $s);
                if (function_exists('rocket_clean_domain')) rocket_clean_domain();
                return true;
            },
            'verify' => function () use ($key, $rec) {
                $s = (array) get_option('wp_rocket_settings', []);
                return (int) ($s[$key] ?? 0) === (int) $rec;
            },
            'revert' => function ($entry) use ($key) {
                $prev = $entry['previous'] ?? '';
                $val = is_string($prev) && strpos($prev, ':') !== false
                    ? (int) trim(substr($prev, strpos($prev, ':') + 1))
                    : 0;
                $s = (array) get_option('wp_rocket_settings', []);
                $s[$key] = $val;
                update_option('wp_rocket_settings', $s);
                if (function_exists('rocket_clean_domain')) rocket_clean_domain();
                return true;
            },
        ];
    }

    // Heartbeat throttle: si está desactivado, el valor por defecto es 60s
    if (!empty($settings['control_heartbeat'])) {
        $admin = $settings['heartbeat_admin_behavior'] ?? 'reduce_periodicity';
        if ($admin === 'disable') {
            $issues[] = [
                'id' => 'wpr-heartbeat-disabled-admin',
                'title' => 'Heartbeat completamente desactivado en admin',
                'why' => 'Mejor "reduce" (60s) que "disable" — algunos plugins lo necesitan (ej: edits autosave).',
                'severity' => 'low',
                'current' => 'admin: disable',
                'suggested' => 'admin: reduce',
                'apply' => function () {
                    $s = (array) get_option('wp_rocket_settings', []);
                    $s['heartbeat_admin_behavior'] = 'reduce_periodicity';
                    update_option('wp_rocket_settings', $s);
                    return true;
                },
            ];
        }
    }

    // Database cleanup automático
    if (empty($settings['schedule_automatic_cleanup'])) {
        $issues[] = [
            'id' => 'wpr-db-cleanup',
            'title' => 'Limpieza automática de base de datos desactivada',
            'why' => 'Acumula revisiones, transients expirados, comentarios spam. Limpieza semanal mantiene la DB rápida.',
            'severity' => 'low',
            'current' => 'schedule_automatic_cleanup: 0',
            'suggested' => 'schedule_automatic_cleanup: 1, frequency: weekly',
            'apply' => function () {
                $s = (array) get_option('wp_rocket_settings', []);
                $s['schedule_automatic_cleanup'] = 1;
                $s['automatic_cleanup_frequency'] = 'weekly';
                update_option('wp_rocket_settings', $s);
                return true;
            },
            'revert' => function () {
                $s = (array) get_option('wp_rocket_settings', []);
                $s['schedule_automatic_cleanup'] = 0;
                update_option('wp_rocket_settings', $s);
                return true;
            },
        ];
    }

    return $issues;
}
}
